﻿# 原版實作驗證紀錄

## 規格依據

- 唯一需求來源：[docs/spec.md](docs/spec.md)。未讀取其來源連結、父目錄、其他案例、Skill 或原始需求。
- 本次明確授權實作，取代規格「本階段不實作程式」的階段說明；沒有改動規格正文。
- 功能目的：依「目的與範圍」，讓營運人員以本機付款 CSV 核對付款筆數與核准金額；不執行付款，不修改來源。
- 完成條件：依「命令列回應」「驗收情境」，實際 CLI 成功輸出恰好五個整數欄位與換行；錯誤輸出固定失敗回應；檔案不變；模組契約、列明的成功與錯誤案例、兩種資料量的結果及記憶體門檻皆經驗證。
- 模組責任：依「責任與契約」，`csv_reader.iter_records(path)` 唯一負責讀檔與格式驗證，逐筆產出合法狀態與整數金額；`summary.summarize(records)` 唯一負責單次走訪與統計；`main.py` 只串接兩者、等待完整成功後輸出 JSON，並轉換讀檔或走訪期間的輸入錯誤。
- 失敗結果：依「命令列回應」，stdout 空、stderr 只有 `INVALID_INPUT` 與換行、exit code `2`；包括後段錯誤，均不得輸出部分統計或修改檔案。
- 效能量測方法：依「品質要求」，先產生合法 CSV，從首筆起循環排列 `APPROVED,100`、`DECLINED,200`、`PENDING,300`。每次啟動新 Python 程序，經 `runpy.run_path(..., run_name="__main__")` 執行實際 `main.py` 入口，使用 `tracemalloc` 取得配置記憶體峰值，`perf_counter` 記錄耗時；資料產生、雜湊與量測報告寫檔均在追蹤範圍外。量測工具的標準函式庫載入先完成，追蹤包含入口分派、產品模組載入及執行；兩次方法一致。

## TDD 證據

先建立可匯入、可執行的空實作及規格測試，才補上產品行為。空實作的讀檔器回傳空 iterator，統計器回傳五個零；入口沒有輸入例外轉換。

執行命令：

```text
python -m unittest -v test_modules
```

- Red：13 個測試方法執行，49 個斷言失敗、2 個未轉換的輸入例外，exit code `1`。完整原始輸出：[red.log](red.log)。
- 有效 Red 例一：合法三筆資料預期取得 3 筆，實際 `0 != 3`。
- 有效 Red 例二：合法紀錄預期 `[("APPROVED", 100), ("DECLINED", 200), ("PENDING", 0)]`，實際為空清單。
- 有效 Red 例三：錯誤格式預期 `ValueError`，實際 `AssertionError: ValueError not raised`。
- 有效 Red 例四：統計預期總筆數 4、核准筆數 2、核准金額 1，空實作實際全部為 0。
- 有效 Red 例五：來源走訪中失敗預期拋出 `ValueError`，實際未走訪來源而沒有錯誤。
- 另 2 個 error 是入口未轉換 `ValueError`、`OSError`，不是語法、匯入、環境或測試程式錯誤；有效 Red 的依據為以上具體斷言失敗。
- Green：補上最小三模組實作，原測試未刪除或放寬，13 個測試方法全部通過，exit code `0`。完整輸出：[green.log](green.log)。
- 整理檢查：保留三個既定模組，統計規則只存在 `summary.py`；無整批載入、無新增依賴、無額外模式或功能，因此沒有需要追加的重構。

模組驗證涵蓋合法解析、空來源、欄位與編碼錯誤、無法讀檔、後段錯誤、只有一次 `__iter__` 的來源、來源未被修改、統計無輸出，以及 main 在取得來源與走訪期間的錯誤轉換。

## CLI 驗收

執行命令：

```text
python verify_cli.py
```

測試器對每案啟動 `python main.py <實際檔案路徑>` 子程序，不以 mock 取代 CLI。檢查 stdout、stderr、退出碼、JSON 欄位與整數型別，並比較來源檔案執行前後 SHA-256。

- 44 個一般 CLI 案例全部通過，含 LF、CRLF、引用資料欄位、只有表頭、零與前導零，以及所有列明的輸入錯誤；每一狀態均測試七種非法金額。
- 後段錯誤包含合法紀錄後的錯誤狀態、錯誤金額，以及 1,000 筆合法紀錄後的無效 UTF-8。
- 實際讀取錯誤使用不存在檔案及無法當作檔案讀取的目錄路徑；沒有修改 OS 權限。讀取途中 `OSError` 另以模組測試來源驗證轉換。
- 成功案皆為一個 JSON 物件及換行、stderr 空、exit code `0`；錯誤案皆 stdout 空、stderr `INVALID_INPUT` 與換行、exit code `2`。
- Windows 實際 CLI 換行為 CRLF；驗證接受平台標準換行，未剝除額外空白或忽略多餘輸出。
- 全部既有來源檔案的前後 SHA-256 相同。
- 人讀紀錄：[cli.log](cli.log)。逐案實際命令、完整輸出、退出碼與前後雜湊：[cli-evidence.json](cli-evidence.json)。可重用的測試輸入與量測數值位於 `test-artifacts/`。

## 效能結果

環境：同一台 Windows 11（10.0.26200）、Python 3.13.13，兩次使用相同 Python 執行檔，每次建立新程序。

| 資料筆數 | 峰值 bytes | 耗時秒 | 總筆數 | 核准／拒絕／待處理筆數 | 核准金額 TWD 分 |
| ---: | ---: | ---: | ---: | --- | ---: |
| 1,000 | 981,221 | 0.035003 | 1,000 | 334／333／333 | 33,400 |
| 200,000 | 988,571 | 1.119343 | 200,000 | 66,667／66,667／66,666 | 6,666,700 |

- 峰值增量 `988571 - 981221 = 7350 bytes`，小於門檻 `8388608 bytes`，通過。
- 兩次 stdout 結果符合規格，stderr 空、exit code `0`，來源檔案不變。
- 耗時只記錄，不設通過門檻。本數字是 Python 配置記憶體，沒有將其宣稱為 OS RSS 或正式環境效能。

## 交付檔案

- 產品：`csv_reader.py`、`summary.py`、`main.py`。
- 測試與量測：`test_cases.py`、`test_modules.py`、`verify_cli.py`、`measure_entry.py`。
- 證據：本文件、`red.log`、`green.log`、`cli.log`、`cli-evidence.json`、`test-artifacts/`。
- 原規格未修改，未進行任何後續規則變更。
