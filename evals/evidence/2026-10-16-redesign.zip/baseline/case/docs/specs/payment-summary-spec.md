# 付款狀態統計：功能規格

## 功能概述

營運人員讀取本機付款結果 CSV，取得付款筆數與核准金額，用於核對。

- 範圍：只讀取、驗證與統計；不執行付款、不修改來源檔案。
- 依據：[付款狀態統計需求](../../inputs/requirements.md)。
- 技術設計：[付款狀態統計設計](payment-summary-design.md)。

## 使用情境

- 營運人員以 `python main.py input.csv` 啟動統計，恰好提供一個檔案路徑。
- 本次只涵蓋上述命令列形式。
- 輸入須符合下列格式規則；檔案無法讀取或內容不合法時，依錯誤規則結束。

## 輸入、輸出與完成條件

- 輸入：指定路徑的 CSV，內容為付款狀態與金額；格式見「BR-PAY-001：輸入格式」。
- 輸出：以下五個整數欄位組成的結果物件，不增列欄位；計算方式見「BR-PAY-002：統計規則」。

| 欄位 | 意義 |
| --- | --- |
| `totalCount` | 全部有效付款紀錄筆數 |
| `approvedCount` | `APPROVED` 筆數 |
| `declinedCount` | `DECLINED` 筆數 |
| `pendingCount` | `PENDING` 筆數 |
| `approvedAmountMinor` | 核准金額合計，單位為 TWD 分 |

- 全部紀錄讀取、驗證及統計完成後才能輸出成功結果。任一輸入錯誤使本次操作失敗。
- 對外完成結果以「BR-PAY-003：命令列回應」規定的標準輸出、標準錯誤與結束碼判定。

## 業務規則

### BR-PAY-001：輸入格式

- 檔案編碼為 UTF-8，無 BOM；逗號分隔，引用欄位沿用 Python 標準 `csv` 模組解析方式，接受 LF 或 CRLF 換行。
- 第一列必須精確為 `status,amount_minor`。
- 每筆後續紀錄恰好兩欄，不去除空白；空白紀錄、缺欄、多欄均不合法。
- `status` 只接受 `APPROVED`、`DECLINED`、`PENDING`，區分大小寫。
- `amount_minor` 只接受至少一個 ASCII 數字組成的非負整數；允許零與前導零，不接受符號、小數、空白或非 ASCII 數字。
- 金額單位固定為 TWD 分；前導零不改變數值，例如 `001` 的值為 `1`。
- 只有正確表頭是合法輸入；空檔、錯誤表頭、無效 UTF-8、無法讀檔或任一不合法紀錄均屬輸入錯誤。

### BR-PAY-002：統計規則

- 每筆有效紀錄使 `totalCount` 加一，並依狀態使對應狀態筆數加一。
- 只有 `APPROVED` 的金額計入 `approvedAmountMinor`；`DECLINED`、`PENDING` 不計金額。
- 結果須滿足 `totalCount = approvedCount + declinedCount + pendingCount`。
- 只有合法表頭時，五個欄位全部為零。

### BR-PAY-003：命令列回應

| 結果 | stdout（標準輸出） | stderr（標準錯誤） | exit code（結束碼） |
| --- | --- | --- | --- |
| 成功 | 一個 JSON 物件及換行，包含本規格定義的五個整數欄位；欄位順序不限 | 空 | `0` |
| 輸入錯誤 | 空，不得輸出部分成功結果 | 只有 `INVALID_INPUT` 及換行 | `2` |

即使前面已有合法紀錄，後續紀錄出錯仍只回傳上述錯誤結果。

### BR-PAY-004：唯讀處理

成功與失敗均不得修改來源檔案，不執行任何付款。

## 處理流程

1. 營運人員從命令列指定一個檔案路徑。
2. 逐筆讀取與檢查「BR-PAY-001：輸入格式」，並依「BR-PAY-002：統計規則」累計結果。
3. 若任一步驟出現輸入錯誤，依「BR-PAY-003：命令列回應」結束，不交付部分統計。
4. 全部處理完成後，交付成功結果；全程遵守「BR-PAY-004：唯讀處理」。

## 品質要求

- 使用 Python 3，僅標準函式庫，不新增依賴或服務。
- 檔案逐筆處理，記憶體不得隨紀錄數線性增加。
- 效能驗收在同一 Python 版本與機器，各以新程序從 `main.py` 入口執行，使用 `tracemalloc` 量測 Python 配置記憶體峰值。
- 測量檔案分別含 1,000 與 200,000 筆資料，皆有合法表頭，資料固定輪流為 `APPROVED,100`、`DECLINED,200`、`PENDING,300`。
- 大檔相對小檔的峰值增量不得超過 8 MiB，即 8,388,608 bytes。
- 記錄兩次執行耗時，不設定時間通過門檻。上述量測不代表作業系統 RSS 或正式環境效能。

## 驗收情境

以下情境皆從實際命令 `python main.py input.csv` 驗證；`input.csv` 代表各情境指定的檔案。表格內多種輸入須分別執行。

### BDD-PAY-001：三種狀態統計

對應規則：BR-PAY-001 輸入格式、BR-PAY-002 統計規則、BR-PAY-003 命令列回應、BR-PAY-004 唯讀處理。

- **Given** 合法表頭後依序為 `APPROVED,100`、`DECLINED,200`、`PENDING,300`。
- **When** 執行 CLI。
- **Then** stdout 輸出五欄 JSON 及換行，`totalCount=3`、各狀態筆數均為 `1`、`approvedAmountMinor=100`；stderr 為空，結束碼為 `0`，來源檔案不變。

### BDD-PAY-002：只有表頭

對應規則：BR-PAY-001 輸入格式、BR-PAY-002 統計規則、BR-PAY-003 命令列回應。

- **Given** 檔案只有合法表頭，沒有付款紀錄。
- **When** 執行 CLI。
- **Then** stdout 輸出五個欄位均為 `0` 的 JSON 及換行；stderr 為空，結束碼為 `0`，來源檔案不變。

### BDD-PAY-003：零與前導零

對應規則：BR-PAY-001 輸入格式、BR-PAY-002 統計規則、BR-PAY-003 命令列回應。

- **Given** 合法表頭後為 `APPROVED,0`、`APPROVED,001`。
- **When** 執行 CLI。
- **Then** stdout 的 JSON 為 `totalCount=2`、`approvedCount=2`、`declinedCount=0`、`pendingCount=0`、`approvedAmountMinor=1`，並有結尾換行；stderr 為空，結束碼為 `0`，來源檔案不變。

### BDD-PAY-004：後段錯誤不輸出部分結果

對應規則：BR-PAY-001 輸入格式、BR-PAY-003 命令列回應。

- **Given** 合法表頭與 `APPROVED,100` 後，分別接上 `UNKNOWN,200` 或 `APPROVED,-1`。
- **When** 執行 CLI。
- **Then** stdout 為空，stderr 只有 `INVALID_INPUT` 及換行，結束碼為 `2`；沒有部分統計，來源檔案不變。

### BDD-PAY-005：檔案與格式錯誤

對應規則：BR-PAY-001 輸入格式、BR-PAY-003 命令列回應、BR-PAY-004 唯讀處理。

- **Given** 下列任一輸入，資料列錯誤案例皆使用合法表頭。

| 類型 | 測試輸入 |
| --- | --- |
| 空檔 | 零位元組檔案 |
| 表頭錯誤 | `status,amount`，或前後多出空白的表頭 |
| 編碼錯誤 | UTF-8 BOM，或無效 UTF-8 位元組 |
| 無法讀檔 | 不存在或無法讀取的路徑 |
| 欄位數錯誤 | 空白紀錄、`APPROVED`、`APPROVED,100,extra` |
| 狀態錯誤 | `approved,100`、`UNKNOWN,100`、` APPROVED,100` |
| 金額錯誤 | `APPROVED,`、`APPROVED,+1`、`APPROVED,-1`、`APPROVED,1.0`、`APPROVED, 1`、`APPROVED,１` |

- **When** 執行 CLI。
- **Then** stdout 為空，stderr 只有 `INVALID_INPUT` 及換行，結束碼為 `2`；沒有來源檔案變更。

### BDD-PAY-006：換行與引用欄位

對應規則：BR-PAY-001 輸入格式、BR-PAY-002 統計規則、BR-PAY-003 命令列回應。

- **Given** 合法表頭後為 `"APPROVED","100"`，分別以 LF、CRLF 建立檔案。
- **When** 執行 CLI。
- **Then** stdout 輸出五欄 JSON 及換行，`totalCount=1`、`approvedCount=1`、`declinedCount=0`、`pendingCount=0`、`approvedAmountMinor=100`；stderr 為空，結束碼為 `0`，來源檔案不變。

### BDD-PAY-007：逐筆處理記憶體

對應規則：BR-PAY-002 統計規則、BR-PAY-003 命令列回應；量測條件見「品質要求」。

- **Given** 品質要求指定的兩種大小檔案與相同測量環境。
- **When** 各以新程序從 `main.py` 入口量測 Python 配置記憶體峰值及耗時。
- **Then** 兩次均成功退出、stderr 為空、來源檔案不變；五欄 JSON 結果如下，大檔峰值減去小檔峰值不超過 8 MiB，並記錄耗時。

| 紀錄數 | totalCount | approvedCount | declinedCount | pendingCount | approvedAmountMinor |
| --- | --- | --- | --- | --- | --- |
| 1,000 | 1,000 | 334 | 333 | 333 | 33,400 |
| 200,000 | 200,000 | 66,667 | 66,667 | 66,666 | 6,666,700 |
