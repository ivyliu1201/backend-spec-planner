﻿# 批次付款執行與中斷續作規格

## 目的與範圍

既有內部批次工作者從已受理的付款批次開始執行，逐筆取得扣款結果；中斷後依持久化意圖查證並續作。呼叫在批次終局或停止並交付原因時結束，讓營運流程能辨認成功、失敗及尚未完成的項目。

- 入口為 `BatchCoordinator.execute(batchId)` 與 `BatchCoordinator.resume(batchId)`。
- 原始檔已完成格式、金額及授權驗證，批次已受理為 `READY`。本功能不包含上傳、人工更正及排程頻率。
- 行為依據為 [批次需求](../inputs/requirements.md)；既有分工見 [能力目錄](../inputs/modules.md)。契約採 [v1 操作契約](../inputs/contracts.md)及 [BatchStore v1 狀態契約補充](../inputs/state-contract.md)。本次定案的識別、保存期限、交易及查無紀錄政策已寫入下文與 Design。

## 行為與規則

### 入口與回應

- `execute` 只接受 `READY`；`resume` 只接受 `RUNNING` 或 `WAITING_RECONCILIATION`。
- 任一入口收到終局批次時，回傳既有快照，不變更狀態、不扣款、不查證。
- 批次不存在時回 `BatchNotFound`；其餘不符合入口條件的狀態回 `NotRunnable`，不開始處理。
- 合法非終局呼叫先持久化 `RUNNING`，成功後才能處理或查證項目。對應操作見 [Design：執行流程](design.md#執行流程)。
- 呼叫結束時提供目前批次與項目快照；未完成時一併交付停止原因。快照包含批次狀態、項目狀態與既有結果、檢查點及成功／失敗／未完成筆數。成功保留 `receiptId`，明確拒絕保留 `reason`。
- 儲存不可用時交付 `StoreUnavailable`，只呈現最後已確認的持久化狀態，不把尚未提交的結果說成已保存或已終局。

### 輸入與順序

- 批次與項目沿用既有 UUID。每批至少一筆，各項目具有不重複的 `itemId`、連續 `seq`、`accountId`、正整數 `amountMinor` 及固定幣別 `TWD`；`amountMinor` 沿用既有最小貨幣單位，不自行換算。受理後原始項目不可更改。
- 同批逐筆依 `seq` 執行，不跳過未取得明確結果的項目。終局項目只能重用結果，不得再次呼叫 `debit`。
- 不同批可並行；同一帳戶的扣款未取得明確結果前，不得開始該帳戶的下一筆扣款。排他與持久占用由既有 BatchStore 提供。
- 每筆新扣款須先成功持久化操作意圖並取得帳戶占用，才可呼叫一次 `Debit.debit`。已存在意圖不構成再次扣款的許可。

### 項目結果

| 狀態 | 意義與後續 |
| --- | --- |
| `PENDING` | 尚未建立操作意圖；前項已終局後才可開始。 |
| `IN_FLIGHT` | 意圖與占用已提交，但本地尚無終局結果；不能據此判定是否已扣款。 |
| `SUCCEEDED` | 已保存 Debit 的 `Success`；可釋放占用並繼續。 |
| `FAILED` | 已保存 Debit 的 `Declined`，代表明確拒絕且未扣款；可釋放占用並繼續。 |
| `UNKNOWN` | 結果尚無法確認；保留占用，批次等待查證。 |

- `debit` 的 `Timeout` 表示可能已扣款，須記為 `UNKNOWN`、批次轉為 `WAITING_RECONCILIATION` 並停止後續項目；已成功及已失敗結果保留。
- 只有取得 `Success` 才能聲稱扣款成功；`Timeout`、查無紀錄或本地交易回滾都不代表外部未扣款或已撤銷。
- 外部終局結果須完成本地提交，才能繼續下一項。無法提交時停止，保留原意圖與占用，供恢復查證。

### 恢復與查證

- `resume` 以持久化項目狀態核對實際進度，跳過終局項目；遇到 `IN_FLIGHT` 或 `UNKNOWN` 必須先用原 `operationId` 呼叫 `lookup`，不得直接重扣。
- 一次 `resume` 對待查項目最多查證一次。本功能不自動重試 `debit`、`lookup` 或儲存操作。
- `lookup` 回 `Success` 或 `Declined` 時保存相應終局結果，提交成功後才可繼續後續 `PENDING` 項目。
- `lookup` 回 `Pending`、`NotFound`、`Expired` 或 `Unavailable` 時，維持項目 `UNKNOWN`、批次 `WAITING_RECONCILIATION` 及帳戶占用，交付快照與對應原因，停止本次恢復，不重扣、不重送。
- `NotFound` 只代表當下查無紀錄；`NotFound` 與 `Expired` 都須記錄人工核對原因。人工更正流程不在本次範圍。
- 若等待狀態本身也無法提交，依儲存失敗規則停止；不得聲稱等待狀態已持久化。原已提交意圖與占用仍供下次查證。

### 操作識別與保存期限

- 一筆原始項目對應一個操作意圖；`operationId` 與 `retentionDays` 的完整組成及傳值規則定義於 [Design：資料對應](design.md#資料對應)。
- Debit 防重紀錄固定保存 `30 × 24` 小時，自首次受理起算；重啟及重複呼叫不延長。到期維持等待並交人工核對，不重新扣款。
- 防重保證只在既有 Debit 契約範圍內成立；本功能不以工作資料仍存在推定防重紀錄仍有效。

### 進度與彙總

- 檢查點是最後一個連續終局項目的 `seq`，不可越過 `IN_FLIGHT`、`UNKNOWN` 或其他未終局項目；恢復不得只憑檢查點略過項目狀態核對。
- 每筆 `Success` 或 `Declined` 的終局結果、帳戶占用釋放與最後連續終局 `seq` 由同一次 `saveProgress` 交易提交。交易失敗時均不提交；查證取得相同結果後再完成記錄，不重扣。
- 成功數按 `SUCCEEDED` 項目計算；失敗數按 `FAILED` 項目計算；`PENDING`、`IN_FLIGHT`、`UNKNOWN` 都計入未完成數。`成功數 + 失敗數 + 未完成數 = 總筆數`，呼叫及查證次數不計入業務筆數。
- 只有未完成數為零才可保存批次終局。BatchCoordinator 決定終局狀態，BatchStore 持久化：

| 全部項目結果 | 批次終局 |
| --- | --- |
| 全部成功 | `COMPLETED` |
| 全部失敗 | `FAILED` |
| 成功與失敗混合 | `COMPLETED_WITH_ERRORS` |

### 停止條件

- `Busy`、`Conflict` 或 `StoreUnavailable` 都使本次呼叫立即停止並交付原因，不繼續扣款。
- 已提交的意圖、占用及終局結果保留。單次本地交易失敗不提交部分變更，不回滾先前項目，也不假設能撤銷外部扣款。
- 帳戶被其他項目占用時，不取得該帳戶的新扣款權；占用者的意圖與結果不受影響。

## 責任與契約

- BatchCoordinator 擁有流程、業務狀態轉換、操作參數選擇、檢查點及彙總規則，並決定失敗後停止或續作。
- Debit 擁有扣款及查證結果；BatchStore 提供持久化、交易、同批執行排他及全系統帳戶占用，不判斷扣款業務政策，也不呼叫 Debit。
- 操作順序、參數來源與中斷恢復見 [Design](design.md)。沿用上述既有模組與 v1 契約，不新增模組、鎖機制或補償能力。

## 品質要求

- 使用既有內部工作者的執行權限；上游授權驗證已完成。
- 工作資料由既有系統保存 `90` 天，與 Debit 的 `30` 天防重期限分開處理。
- 本案例未另設安全、容量或效能門檻；並行須維持上述同批順序及同帳戶排他規則。

## 驗收情境

下列 Given／When／Then 定義實作後的行為驗收；以兩個 BatchCoordinator 入口觸發，觀察回傳、持久化狀態、Debit 呼叫及帳戶占用。這些是驗收規格，未代表已執行產品測試。

### 逐筆執行與終局彙總

- **Given** 一批 `READY` 資料含三項 `seq=1,2,3`，項目皆為 `PENDING`，帳戶可取得占用，所有本地提交成功。
- **When** 呼叫 `execute(batchId)`，Debit 按下表回應。
- **Then** 依 `seq` 各扣款一次，明確拒絕後仍繼續下一項；每筆均先提交意圖再扣款，終局結果與檢查點同時提交，最終檢查點為 `3`，占用均釋放。回傳結果如下，成功附 `receiptId`、失敗附 `reason`。

| 依序回應 | 批次狀態 | 成功數 | 失敗數 | 未完成數 |
| --- | --- | ---: | ---: | ---: |
| Success、Success、Success | `COMPLETED` | 3 | 0 | 0 |
| Declined、Declined、Declined | `FAILED` | 0 | 3 | 0 |
| Success、Declined、Success | `COMPLETED_WITH_ERRORS` | 2 | 1 | 0 |

### 扣款逾時

- **Given** `READY` 批次有三項，`seq=1` 扣款成功並已提交。
- **When** 同次 `execute(batchId)` 處理 `seq=2` 時取得 `Timeout`，等待狀態提交成功。
- **Then** 批次為 `WAITING_RECONCILIATION`，第 2 項為 `UNKNOWN` 且保留占用，第 3 項維持 `PENDING` 且未呼叫扣款；檢查點為 `1`，筆數為成功 `1`、失敗 `0`、未完成 `2`，回傳逾時原因。

### 恢復查得明確結果

- **Given** 批次為 `RUNNING` 或 `WAITING_RECONCILIATION`，第 1 項成功、第 2 項為 `IN_FLIGHT` 或 `UNKNOWN` 且有原意圖與占用、第 3 項為 `PENDING`。
- **When** 呼叫 `resume(batchId)`，第 2 項 `lookup` 回 `Success` 或 `Declined`，本地保存成功，第 3 項隨後扣款成功。
- **Then** 第 1、2 項都不再扣款；第 2 項只查證一次，記錄對應終局結果並釋放占用，再處理第 3 項。查得成功時批次為 `COMPLETED`、成功數 `3`；查得拒絕時為 `COMPLETED_WITH_ERRORS`、成功數 `2`、失敗數 `1`；兩者未完成數均為 `0`、檢查點為 `3`。

### 恢復仍無法確認結果

- **Given** 批次為 `RUNNING` 或 `WAITING_RECONCILIATION`，第 1 項成功、第 2 項為 `IN_FLIGHT` 或 `UNKNOWN` 且有原意圖與占用、第 3 項為 `PENDING`；檢查點為 `1`，本地等待狀態可保存。
- **When** 呼叫 `resume(batchId)`，第 2 項 `lookup` 回下列任一結果。
- **Then** 只查證一次後停止，第 2 項為 `UNKNOWN`、批次為 `WAITING_RECONCILIATION`，保留其占用；第 3 項未扣款，檢查點仍為 `1`，筆數仍為成功 `1`、失敗 `0`、未完成 `2`，回傳快照與原因。第 2 項不得重扣或重送。

| 查證結果 | 交付原因 |
| --- | --- |
| `Pending` | 已受理但尚未終局。 |
| `NotFound` | 目前查無紀錄，需人工核對，不能推定未扣款。 |
| `Expired` | 防重紀錄已到期，需人工核對。 |
| `Unavailable` | 本次無法查證。 |

### 意圖提交後、扣款前中斷

- **Given** 第 1 項的意圖與占用已提交、狀態為 `IN_FLIGHT`，批次為 `RUNNING`，工作者在呼叫 Debit 前中斷。
- **When** 新工作者呼叫 `resume(batchId)`，`lookup` 回 `NotFound`，等待狀態保存成功。
- **Then** 沿用原 `operationId` 查證一次，轉為 `UNKNOWN` 與 `WAITING_RECONCILIATION`，保留占用並交人工核對，不因實際曾在扣款前中斷而重新扣款。

### 外部結果取得後、本地提交失敗

- **Given** 一項意圖與占用已提交，Debit 回 `Success` 或 `Declined`，但 `saveProgress` 回 `StoreUnavailable`。
- **When** 目前入口呼叫結束，之後工作者以 `resume(batchId)` 恢復，`lookup` 回原終局結果且本地保存成功。
- **Then** 原呼叫回報儲存失敗，不處理下一項；失敗交易不提交終局結果或檢查點，也不釋放占用。恢復先查證原操作，再用相同結果同時保存終局結果與檢查點、釋放占用；原項目不再扣款。

### 狀態提交失敗

- **Given** 批次處於入口可接受的非終局狀態，`load` 成功，但 `markRunning` 回 `StoreUnavailable`。
- **When** 呼叫對應的 `execute(batchId)` 或 `resume(batchId)`。
- **Then** 原批次狀態不變，回報儲存不可用，不開始項目處理、扣款或查證。

### 等待狀態提交失敗

- **Given** 意圖與占用已保存，扣款逾時或恢復查證無明確結果，但 `wait` 回 `StoreUnavailable`。
- **When** 目前 `execute(batchId)` 或 `resume(batchId)` 結束。
- **Then** 回報儲存失敗並停止；不宣稱 `UNKNOWN` 或 `WAITING_RECONCILIATION` 已提交，不繼續扣款，原意圖與占用仍存在，後續 `resume` 先查證。

### 終局保存前中斷

- **Given** 批次仍為 `RUNNING`，所有項目結果、帳戶釋放與檢查點均已提交，但工作者在 `finish` 前中斷，或 `finish` 因儲存不可用未提交。
- **When** 呼叫 `resume(batchId)`，本地操作成功。
- **Then** 按持久化項目結果計算筆數與批次終局並保存；不再扣款或查證已終局項目，呼叫次數不增加業務筆數。

### 重複與不合法入口

- **Given** 下表的批次狀態或不存在的批次識別。
- **When** 呼叫表列入口。
- **Then** 回傳表列結果，不呼叫 Debit，也不變更批次、項目、意圖、占用或檢查點。

| 前提 | 入口 | 結果 |
| --- | --- | --- |
| `COMPLETED`、`COMPLETED_WITH_ERRORS` 或 `FAILED` | execute 或 resume | 原終局快照。 |
| `RUNNING` 或 `WAITING_RECONCILIATION` | execute | `NotRunnable`。 |
| `READY` | resume | `NotRunnable`。 |
| 批次不存在 | execute 或 resume | `BatchNotFound`。 |

### 不同批競爭同帳戶

- **Given** 批次 A 的項目占用帳戶 X 且結果未知；批次 B 的下一項也使用 X。
- **When** B 透過合法入口嘗試處理該項，`beginItem` 回 `Busy`。
- **Then** B 停止並交付 `Busy`，不對 X 扣款；A 的意圖、占用及結果保留。同批執行仍由既有入口排他能力保證，不新增鎖機制。

### 意圖或結果衝突

- **Given** 合法入口處理期間，既有契約操作回 `Conflict`，例如相同項目對應不同意圖，或相同 `operationId` 對應不同扣款內容。
- **When** 該 `execute(batchId)` 或 `resume(batchId)` 收到衝突。
- **Then** 立即停止並交付 `Conflict`，不繼續扣款；不覆寫已保存意圖或結果，不釋放仍需查證的占用。

### 識別與到期

- **Given** 意圖已保存，`operationId` 為原 `batchId:itemId`、`retentionDays` 為 `30`，工作者其後重啟。
- **When** 呼叫 `resume(batchId)`，使用原操作識別查證；首次受理已過 `30 × 24` 小時且 Debit 回 `Expired`。
- **Then** 不產生新識別、不變更或延長保留期間，記錄人工核對原因並維持等待及占用，不重新扣款；工作資料仍依既有 `90` 天政策保存。

