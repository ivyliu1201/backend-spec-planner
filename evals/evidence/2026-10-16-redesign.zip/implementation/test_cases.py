﻿"""Cases transcribed from docs/spec.md, shared by unit and CLI checks."""

HEADER = b"status,amount_minor\n"


def expected(total, approved, declined, pending, amount):
    return {
        "totalCount": total,
        "approvedCount": approved,
        "declinedCount": declined,
        "pendingCount": pending,
        "approvedAmountMinor": amount,
    }


SUCCESS_CASES = [
    ("mixed_lf", HEADER + b"APPROVED,100\nDECLINED,200\nPENDING,300\n", expected(3, 1, 1, 1, 100)),
    ("mixed_crlf", b"status,amount_minor\r\nAPPROVED,100\r\nDECLINED,200\r\nPENDING,300\r\n", expected(3, 1, 1, 1, 100)),
    ("quoted_lf", HEADER + b'"APPROVED","100"\n"DECLINED","200"\n"PENDING","300"\n', expected(3, 1, 1, 1, 100)),
    ("quoted_crlf", b'status,amount_minor\r\n"APPROVED","100"\r\n"DECLINED","200"\r\n"PENDING","300"\r\n', expected(3, 1, 1, 1, 100)),
    ("header_only", HEADER, expected(0, 0, 0, 0, 0)),
    ("zero_and_leading_zero", HEADER + b"APPROVED,0\nAPPROVED,001\n", expected(2, 2, 0, 0, 0)),
    ("approval_amount_threshold", HEADER + b"APPROVED,0\nAPPROVED,99\nAPPROVED,100\nAPPROVED,101\n", expected(4, 4, 0, 0, 201)),
]

INVALID_CASES = [
    ("empty", b""),
    ("reversed_header", b"amount_minor,status\n"),
    ("spaced_header", b"status,amount_minor \n"),
    ("quoted_header", b'"status","amount_minor"\n'),
    ("bom", b"\xef\xbb\xbf" + HEADER),
    ("invalid_utf8", HEADER + b"APPROVED,\xff\n"),
    ("blank_record", HEADER + b"\n"),
    ("missing_field", HEADER + b"APPROVED\n"),
    ("extra_field", HEADER + b"APPROVED,100,extra\n"),
    ("unknown_status", HEADER + b"UNKNOWN,100\n"),
    ("lowercase_status", HEADER + b"approved,100\n"),
    ("spaced_status", HEADER + b"APPROVED ,100\n"),
    ("late_bad_status", HEADER + b"APPROVED,100\nUNKNOWN,200\n"),
    ("late_bad_amount", HEADER + b"APPROVED,100\nAPPROVED,-1\n"),
    ("late_invalid_utf8", HEADER + b"APPROVED,100\n" * 1000 + b"PENDING,\xff\n"),
]
for status in ("APPROVED", "DECLINED", "PENDING"):
    for label, value in (("empty", ""), ("negative", "-1"), ("plus", "+1"), ("decimal", "1.0"), ("leading_space", " 1"), ("trailing_space", "1 "), ("fullwidth", "\uff11")):
        INVALID_CASES.append((status.lower() + "_amount_" + label, HEADER + (status + "," + value + "\n").encode("utf-8")))
