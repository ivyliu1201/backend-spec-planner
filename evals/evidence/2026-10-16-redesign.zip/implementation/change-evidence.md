﻿# 核准金額門檻變更驗證

## 已確認變更

- 唯一新增規則：`APPROVED` 的 `amount_minor < 100` 時仍計入核准筆數，但不納入核准金額；其他規則不變。
- 已確認 BDD：Given `APPROVED,0`、`APPROVED,99`、`APPROVED,100`、`APPROVED,101`；When 執行 CLI；Then `totalCount=4`、`approvedCount=4`、`declinedCount=0`、`pendingCount=0`、`approvedAmountMinor=201`。
- 依本階段明確指示更新 [docs/spec.md](docs/spec.md) 的金額加總條件及驗收表，沒有讀取原始需求、父目錄或其他案例。
- 原有 `APPROVED,0`、`APPROVED,001` 案例的核准金額由 `1` 改成 `0`，計數維持 `2`。輸入格式、三個模組的責任與公開操作、錯誤回應、效能資料及門檻都沒有變更。

## 原版保存與差異

- 修改規格或測試前，將原版 `csv_reader.py`、`summary.py`、`main.py` 與規格複製至 [original-baseline](original-baseline/)，並保存來源及原版證據的 [SHA-256 清單](original-baseline/sha256.json)。
- 新增測試取得 Red 後、修改產品前，再次比對三個產品檔的 SHA-256，確認 Red 使用的確實是原版。
- 產品僅修改 `summary.py`：`approvedCount` 仍每筆加一，只有 `amount >= 100` 才累加 `approvedAmountMinor`。完整差異：[change-product.diff](change-product.diff)。
- `csv_reader.py` 與 `main.py` 內容逐位元組不變；統計門檻仍只由 `summary.py` 負責，沒有移動責任或複製規則。
- 正式規格差異：[change-spec.diff](change-spec.diff)。
- `test_cases.py` 新增已確認的門檻案例，只更新與新規則衝突的零／前導零金額預期。
- `test_modules.py` 新增門檻斷言；既有低金額的統計預期及協調測試中對應的 mock 結果從 `1` 改成 `0`，未刪除或放寬任何斷言。
- `verify_cli.py` 只調整證據及測試資料輸出名稱，使用 `change-` 前綴保存新紀錄。`measure_entry.py` 完全不變。
- [change-scope.json](change-scope.json) 記錄修改前後 SHA-256。範圍斷言確認原有檔案中只有 `docs/spec.md`、`summary.py`、`test_cases.py`、`test_modules.py`、`verify_cli.py` 改變。
- 原版 `test-evidence.md`、`red.log`、`green.log`、`cli.log`、`cli-evidence.json` 皆逐位元組保留；原 `test-artifacts/` 沒有重新寫入。

## TDD

先更新正式規格及受影響情境，再在原版產品上執行新增測試：

```text
python -m unittest -v test_modules.SummaryTests.test_approved_amount_threshold_counts_every_approval
```

- Red：`AssertionError: 300 != 201`，1 個測試、1 個斷言失敗、exit code `1`。原版將 `0 + 99 + 100 + 101` 全數累加，失敗直接揭露尚未實作的門檻行為，沒有語法、匯入或環境錯誤。完整輸出：[change-red.log](change-red.log)。
- 最小修改：只在原有金額累計敘述前加入 `if amount >= 100:`，保留核准筆數累計位置。
- Green／回歸：執行 `python -m unittest -v test_modules`，14 個測試方法全部通過，exit code `0`。包含新增門檻、所有原有模組契約與錯誤轉換。完整輸出：[change-green.log](change-green.log)。
- 責任邊界內檢查完成；這項修改無需新增抽象、依賴或進一步重構。

## 實際 CLI 驗收

執行 `python verify_cli.py`，45 個 CLI 案例全部通過；每案都真正啟動 `python main.py <檔案路徑>`，檢查完整 stdout、stderr、退出碼、JSON 欄位／型別及來源 SHA-256。

新增門檻案例的實際結果：

```json
{"totalCount": 4, "approvedCount": 4, "declinedCount": 0, "pendingCount": 0, "approvedAmountMinor": 201}
```

- stdout 僅上述物件加平台換行；stderr 空；exit code `0`；來源內容不變。
- 原有成功及錯誤案例全數回歸通過；所有錯誤仍只有 `INVALID_INPUT` 與換行、stdout 空、exit code `2`，沒有部分統計。
- 原有零與前導零成功案例輸出核准金額 `0`、總筆數及核准筆數均 `2`，符合更新後規格。
- 日誌：[change-cli.log](change-cli.log)。逐案完整命令、輸出與雜湊：[change-cli-evidence.json](change-cli-evidence.json)。新資料與個別量測值位於 `change-test-artifacts/`。

## 效能回歸

沿用未修改的量測方法與資料序列，在同一台 Windows 11、Python 3.13.13 下，兩次各用新程序從 `main.py` 入口量測；資料事先產生，不計入追蹤。

| 資料筆數 | Python 配置峰值 bytes | 耗時秒 | 核准金額 TWD 分 |
| ---: | ---: | ---: | ---: |
| 1,000 | 981,069 | 0.028794 | 33,400 |
| 200,000 | 988,867 | 1.103538 | 6,666,700 |

- 峰值增量 `988867 - 981069 = 7798 bytes`，小於既有門檻 `8388608 bytes`，通過。
- 兩次五個統計欄位都符合未改動的效能情境預期，stderr 空、exit code `0`，來源內容不變。
- 耗時僅記錄，不設定通過門檻；量測不代表 OS RSS 或正式環境效能。
