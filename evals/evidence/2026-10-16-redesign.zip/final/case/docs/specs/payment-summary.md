# 付款狀態統計

## 目的與範圍

營運人員透過本機命令列取得付款結果 CSV 的筆數與核准金額，供核對使用。

- 只讀取與統計，不執行付款，不修改來源檔案。
- 使用 Python 3 與標準函式庫，不新增依賴或服務。
- 入口為 `python main.py input.csv`，恰好提供一個檔案路徑；其他命令列形式不在本次範圍。

依據：[付款狀態統計需求](../../inputs/requirements.md#付款狀態統計)中的技術限制與驗收情境。

## 行為與規則

### CSV 輸入

- 檔案使用 UTF-8 編碼，不含 BOM；接受 LF 或 CRLF 換行。
- 以逗號分隔，引用欄位沿用 Python 標準 `csv` 模組的解析方式。
- 第一列必須精確為 `status,amount_minor`。
- 後續每個紀錄恰好兩欄，不去除空白；空白紀錄、缺欄或多欄均不合法。
- 只有合法表頭的檔案有效；空檔不合法。

| 欄位 | 有效值 | 用途 |
| --- | --- | --- |
| `status` | 僅限 `APPROVED`、`DECLINED`、`PENDING`，區分大小寫 | 決定狀態筆數與是否累加金額 |
| `amount_minor` | 至少一個 ASCII 數字組成的非負整數；可為零或含前導零，不接受符號、小數或空白 | 轉為整數，單位固定為 TWD 分 |

### 統計結果

每個有效紀錄計入總筆數及其所屬狀態的筆數；只有核准紀錄累加金額。

| 結果欄位 | 計算規則 |
| --- | --- |
| `totalCount` | 全部有效紀錄的筆數 |
| `approvedCount` | `APPROVED` 紀錄的筆數 |
| `declinedCount` | `DECLINED` 紀錄的筆數 |
| `pendingCount` | `PENDING` 紀錄的筆數 |
| `approvedAmountMinor` | `APPROVED` 紀錄的 `amount_minor` 整數加總，單位為 TWD 分 |

- 結果恰有上述五個欄位，值均為整數。
- `totalCount = approvedCount + declinedCount + pendingCount`。
- 只有合法表頭時，五個值均為零。
- `DECLINED` 與 `PENDING` 的金額仍須合法，但不計入核准金額。

### CLI 回應

CLI（命令列介面）在讀完並驗證全部紀錄後，才能輸出成功結果。

| 結果 | stdout（標準輸出） | stderr（標準錯誤輸出） | Exit code |
| --- | --- | --- | --- |
| 成功 | 一個符合「統計結果」的 JSON 物件及換行；欄位順序不限 | 空 | `0` |
| 輸入失敗 | 完全沒有內容 | 僅 `INVALID_INPUT` 及換行 | `2` |

輸入失敗涵蓋：空檔、表頭錯誤、無法讀檔、無效 UTF-8，以及任一紀錄不符合「CSV 輸入」。即使前面已有合法紀錄，也不得輸出部分統計。成功或失敗均不得修改來源檔案。

## 責任與契約

### `csv_reader.iter_records(path)`

- **責任**：讀檔、解析 CSV，驗證編碼、表頭與每個紀錄，擁有「CSV 輸入」的驗證規則。
- **輸入**：由 `main.py` 傳入命令列提供的檔案路徑。
- **輸出**：逐筆產生 `(status, amount_minor)`；`status` 為有效狀態字串，`amount_minor` 為有效金額整數。
- **失敗**：格式錯誤以 `ValueError` 表示，檔案讀取錯誤可維持 `OSError`；逐筆讀取時發現的錯誤必須向呼叫端傳遞，不能略過紀錄。
- **界線**：不計算統計、不輸出 CLI 回應、不修改來源檔案。

### `summary.summarize(records)`

- **責任**：擁有「統計結果」的全部計算規則。
- **輸入**：僅可走訪一次的有效紀錄來源，其元素為上述 `(status, amount_minor)`。
- **輸出**：走訪完來源後，回傳包含五個整數欄位的結果物件；空來源回傳五個零。
- **失敗**：來源走訪期間發生輸入錯誤時，不回傳部分成功結果，將錯誤傳回協調端。
- **界線**：不讀檔、不輸出、不修改來源；不要求來源可重複走訪。

### `main.py`

- **責任**：協調呼叫、序列化成功結果，並決定「CLI 回應」。
- **順序**：取得檔案路徑 → 呼叫 `csv_reader.iter_records(path)` → 將紀錄來源交給 `summary.summarize(records)` → 全部成功後輸出 JSON 並退出。
- **錯誤處理**：涵蓋建立與走訪紀錄來源期間的上述輸入錯誤，轉成指定的失敗回應。
- **界線**：不複製統計規則；不得為協調流程先將全部紀錄載入記憶體。

三者採直接協作，不要求工廠、外掛、Repository 或其他模式；符合上述行為與責任的內部等價寫法保留彈性。

## 品質要求

### 記憶體

- 檔案逐筆處理，記憶體不得隨紀錄數線性增加。
- 在同一機器、同一 Python 版本，以兩個新程序分別從 `main.py` 入口量測 1,000 筆及 200,000 筆輸入。
- 兩份檔案均有合法表頭，資料從第一筆起固定循環為 `APPROVED,100`、`DECLINED,200`、`PENDING,300`，直到指定筆數。
- 使用相同量測方式，以 `tracemalloc` 記錄 Python 配置記憶體峰值；測量檔案事先建立，不能把產生測試資料的配置量算入被測程式。
- 通過門檻：200,000 筆的峰值減去 1,000 筆的峰值，不超過 8 MiB（8,388,608 bytes）。
- 同時記錄兩次耗時，不設定時間通過門檻；此量測不代表作業系統 RSS 或正式環境效能。

## 驗收情境

下列情境均從實際入口執行；來源檔案存在時，執行前後內容必須相同。

### 混合狀態

- **Given** 檔案含合法表頭，以及依序為 `APPROVED,100`、`DECLINED,200`、`PENDING,300` 的三筆紀錄。
- **When** 執行 `python main.py input.csv`。
- **Then** stdout 為一個 JSON 物件及換行，欄位恰為 `totalCount=3`、`approvedCount=1`、`declinedCount=1`、`pendingCount=1`、`approvedAmountMinor=100`，值均為整數；stderr 為空、exit code 為 `0`，來源檔案不變。

### 只有表頭

- **Given** 檔案只有合法表頭，沒有資料紀錄。
- **When** 執行 `python main.py input.csv`。
- **Then** stdout 為包含五個結果欄位的 JSON 物件及換行，所有值為整數 `0`；stderr 為空、exit code 為 `0`，來源檔案不變。

### 零與前導零

- **Given** 檔案含合法表頭，以及 `APPROVED,0`、`APPROVED,001`。
- **When** 執行 `python main.py input.csv`。
- **Then** stdout 為一個 JSON 物件及換行，欄位恰為 `totalCount=2`、`approvedCount=2`、`declinedCount=0`、`pendingCount=0`、`approvedAmountMinor=1`，值均為整數；stderr 為空、exit code 為 `0`，來源檔案不變。

### 後續紀錄不合法

- **Given** 檔案含合法表頭與 `APPROVED,100`，後面再出現不合法狀態或金額，例如 `UNKNOWN,200` 或 `DECLINED,-1`。
- **When** 分別執行 `python main.py input.csv`。
- **Then** stdout 沒有任何內容，stderr 僅為 `INVALID_INPUT` 及換行，exit code 為 `2`；沒有部分統計，來源檔案不變。

### 檔案與格式錯誤

- **Given** 輸入分別具有下表的一項錯誤；資料紀錄錯誤的案例皆保留合法表頭。
- **When** 對每個案例執行 `python main.py input.csv`。
- **Then** stdout 沒有任何內容，stderr 僅為 `INVALID_INPUT` 及換行，exit code 為 `2`；存在的來源檔案不變。

| 類別 | 輸入例子 |
| --- | --- |
| 讀取失敗 | 不存在或無法讀取的檔案路徑 |
| 編碼錯誤 | 含無效 UTF-8 位元組，或檔案開頭含 BOM |
| 空檔 | 沒有任何內容 |
| 表頭錯誤 | `amount_minor,status`、`Status,amount_minor`、`status,amount_minor ` |
| 紀錄欄數錯誤 | 空白紀錄、`APPROVED`、`APPROVED,1,extra` |
| 狀態錯誤 | `approved,1`、`UNKNOWN,1`、`,1`、` APPROVED,1` |
| 金額錯誤 | `APPROVED,`、`APPROVED,-1`、`APPROVED,+1`、`APPROVED,1.0`、`APPROVED, 1`、`APPROVED,1 `、`APPROVED,１` |

合法資料的驗收應包含 LF 與 CRLF，以及標準 `csv` 模組接受的引用欄位，例如資料紀錄 `"APPROVED","001"`；解析後應依相同規則計數與加總。

### 逐筆處理容量

- **Given** 依「記憶體」準備的 1,000 筆及 200,000 筆合法檔案，使用同一機器與 Python 版本。
- **When** 以兩個新程序分別從 `main.py` 入口執行兩份檔案，使用 `tracemalloc` 取得 Python 配置記憶體峰值並記錄耗時。
- **Then** 兩次均輸出一個 JSON 物件及換行，恰含下表五個整數欄位；stderr 為空、exit code 為 `0`，來源檔案不變；大檔峰值減去小檔峰值不超過 8 MiB，耗時只記錄而不作通過門檻。

| 輸入筆數 | `totalCount` | `approvedCount` | `declinedCount` | `pendingCount` | `approvedAmountMinor` |
| --- | --- | --- | --- | --- | --- |
| 1,000 | 1,000 | 334 | 333 | 333 | 33,400 |
| 200,000 | 200,000 | 66,667 | 66,667 | 66,666 | 6,666,700 |
