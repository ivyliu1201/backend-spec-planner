---
name: backend-spec-planner
description: "僅在使用者明確呼叫 $backend-spec-planner 時，從需求、文件或程式證據建立、修訂、逆向整理或審查後端規格。交付人能理解、AI 能據以開發的精煉規格，涵蓋可驗收行為、責任邊界、操作契約與必要品質要求；批次處理及複雜領域設計按需深入。"
---

# Backend Spec Planner

將需求整理成可交付開發的最小充分規格：讀者能理解目的，開發者能找到行為、責任與契約，驗收者能判定結果。

## 適用範圍

- 僅在明確呼叫 $backend-spec-planner 的規格任務及續談使用；需求敘述、文件或程式路徑即可開始。
- 審查只回報，修改須有授權。保留已確認的行為、模組、階段與責任；調整前說明原因、影響與方案並取得同意。
- 單一功能的決策只適用於指定範圍；本 Skill 負責規格與必要設計，規格完成不代表取得開發許可。

## 工作流程

1. 讀取適用的 AGENTS.md、需求、指定文件及直接相關的規範，確認目的與範圍。
2. 逆向分析、資料不足或涉及責任／契約時，沿相關入口與公開契約查證；仍有重要歧義才深入實作及測試。
3. 以具體情境釐清正常、失敗與邊界結果，依下節完成必要訪談及[驗收確認](references/authoring-rules.md#驗收)。有充分依據的局部修訂可直接處理。
4. 依已確認行為設計責任、操作契約與品質約束；沿用既有架構，按問題選用 DDD 或設計模式，不預設增加層次或抽象。發現影響需求的新缺口時回到訪談。
5. 選用最少必要文件，依[完整性](references/authoring-rules.md#完整性)與[開發交接](references/authoring-rules.md#開發交接)核對，交付位置、修改摘要及驗證範圍。

選用既有模組時，先從能力目錄辨識協作或替代關係，選定操作後讀必要契約；契約不符再回查候選。無目錄則從相關來源辨識能力，不為此固定建立目錄。

## 需求訪談

- 預設交付正式規格。缺口會改變業務結果、驗收、公開契約、責任或授權時，先釐清再生成。
- 每次只問最影響結果的一題，先說明推薦、理由與影響，收到回答後再繼續。
- 已有答案不重問；等價內部寫法與局部編排自行處理。
- 等待時可查證或整理無依賴內容；必要決策未定前不交付帶缺口的規格，也不以沉默或預選代替回答。
- 明確要求草案、分析、審查或逆向現況時，依委託交付；來源與正式文件寫法依[撰寫準則](references/authoring-rules.md#依據)。

## 資料載入

依本次需要讀取；純文字整理只核對受影響內容與引用。

| 判斷內容 | 資源 |
| --- | --- |
| 完整性、編排、來源、驗收與開發交接 | [authoring-rules.md](references/authoring-rules.md) |
| 責任、契約、設計取捨與效能 | [design-rules.md](references/design-rules.md) |
| 批次與檔案處理 | [batch-processing.md](references/batch-processing.md) |

## 文件選用

沿用既有命名、位置與文件邊界；無慣例時使用 docs/specs/。只建立本次需要的文件。

- **新建**：沿用團隊模板；沒有時以一份 [Feature Spec](assets/templates/spec.md)開始，包含行為與必要設計。模板提供建議閱讀順序，依內容合併或省略無用途的章節，不填空表或「不適用」湊格式。
- **拆分**：責任互動、交易或重要取捨需詳細展開，且拆分有助閱讀時，才另寫 [Feature Design](assets/templates/design.md)。Spec 保留行為與驗收，設計細節在一處維護；使用者指定分開交付時遵從。
- **共用**：多個功能確有重用需求時才使用 System Context、Module Catalog 或 Module Contract；已有足夠來源直接引用，單次功能資料留在 Spec 或 Design。
- **修訂**：保留原結構，只改受影響內容。整份格式統一須區分格式整理與業務行為變更。

| 按需文件 | 責任 |
| --- | --- |
| [System Context](assets/templates/system-context.md) | 共用背景、術語、責任邊界與規則 |
| [Module Catalog](assets/templates/module-catalog.md) | 模組能力、協作及替代選用 |
| [Module Contract](assets/templates/module-contract.md) | 共用操作的呼叫條件、回應及限制；已有契約引用，不足處補齊 |

交付前移除模板提示、註解與佔位符，引用改為實際文件位置。規格中的 BDD 是驗收定義；未實作或未執行的產品測試不得報為通過。

使用說明見 [README.md](README.md)。僅維護或評估本 Skill 時讀取 [evals/cases.md](evals/cases.md)。
