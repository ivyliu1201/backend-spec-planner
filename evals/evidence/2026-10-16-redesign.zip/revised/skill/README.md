<div align="center">

# backend-spec-planner

**產出精煉、可交付開發的後端規格**

依據需求、既有文件與程式證據，整理可驗收行為、模組責任及操作契約。  
簡單功能以一份規格交付，必要設計按需深入，讓人與 AI 都能找到開發依據。

[適用情境](#適用情境) · [安裝方式](#安裝方式) · [使用範例](#使用範例) · [工作流程](#工作流程) · [文件產出](#文件產出) · [生成示例](#生成示例) · [驗證狀態](#驗證狀態)

</div>

## 適用情境

- **建立規格**：從需求敘述整理用例、業務規則、例外與驗收情境。
- **修訂既有文件**：分析現有 spec 的缺口，沿用原有結構調整受影響內容。
- **規格審查**：檢查行為、設計、契約與責任分工是否一致。
- **逆向整理**：依既有入口與相關程式描述目前行為，區分實作現況與已確認需求。

以需求釐清、責任與契約設計、BDD（行為驅動開發）為核心。DDD（領域驅動設計）與設計模式只在能解決具體問題時採用；批次與檔案處理按需檢查格式、防重、交易及恢復。效能要求須有負載條件、指標及量測方法。

## 安裝方式

本專案由指令、參考文件與模板組成，沒有套件安裝、建置或服務啟動步驟。

1. 將完整 Skill 內容放在名為 `backend-spec-planner` 的資料夾中。本儲存庫根目錄已是 Skill 根目錄，`SKILL.md` 應直接位於其中。
2. 依使用範圍選擇放置位置：

   | 使用範圍 | 路徑 |
   | --- | --- |
   | 個人使用，跨專案共用 | `~/.codex/skills/backend-spec-planner/` |
   | 僅供指定專案使用 | `<專案根目錄>/.codex/skills/backend-spec-planner/` |

   `~` 代表使用者家目錄。保留 `agents/`、`references/`、`assets/` 與 `evals/` 的相對位置。

3. 在 Codex 開啟目標專案，確認 Skill 已出現在可用清單；若未出現，可重新啟動 Codex。

位置與使用方式依 [Codex 官方 Skills 文件](https://learn.chatgpt.com/docs/build-skills)整理。本 Skill 設定為明確呼叫，使用 `$backend-spec-planner` 啟動；實際宿主驗證狀態見下方說明。

## 使用範例

### 修訂既有規格

指定文件與目的即可開始，不必先選模板或決定文件數量：

```text
$backend-spec-planner
請分析並調整 docs/spec.md，沿用既有結構。
涉及新的業務決策時，先提出建議讓我確認。
```

### 建立正式規格

```text
$backend-spec-planner
請依需求文件建立批次結果查詢的正式規格。
必要問題先在對話中一題一題問清楚，再產出完整文件。
```

### 審查規格一致性

```text
$backend-spec-planner
請審查 docs/specs/payroll/ 的規格與設計。
重點檢查模組責任、受理與完成條件、重試及失敗處理，只回報，不修改。
```

### 逆向整理現有行為

```text
$backend-spec-planner
請從既有批次提交入口及相關契約整理目前規格，
保留文件與程式之間的差異，區分實作現況與已確認需求。
```

上述路徑與功能名稱均為示例，可依專案調整。同一規格任務的後續對話可直接補充需求或回覆決策，不必重複呼叫名稱。

## 工作流程

| 處理環節 | 主要內容 |
| --- | --- |
| 範圍與來源確認 | 讀取指定文件、適用規則及直接相關的依據 |
| 缺口與影響分析 | 判斷哪些歧義會改變業務結果、契約、資料一致性或責任 |
| 必要證據查核 | 資料不足、逆向分析或涉及模組／契約時，才追查相關來源 |
| 必要訪談 | 先說明推薦、理由與影響，每次問一題，收到答案再繼續 |
| 內容撰寫與修訂 | 確認情境與必要決策後，以最少必要文件產出正式規格 |
| 開發交接核對 | 確認只讀規格與引用資料即可找到行為、責任、契約及驗收，回報檢查範圍 |

- 資料已充分時直接撰寫，不重問已有答案，也不為等價的內部寫法訪談。
- 正式規格直接描述行為、責任與設計理由；問題與選項留在對話，必要的來源引用仍保留。
- 明確要求先看草案時才交草案；只審查時在對話回報發現。

流程與授權邊界見 [SKILL.md](SKILL.md#需求訪談)。

## 文件產出

**文件數量依實際需求決定。** 修改一份既有 `spec.md`，通常仍只修改該檔；審查任務則在對話中回報。沒有既有位置慣例時，才使用 `docs/specs/`。

新建功能預設以一份 [Feature Spec](assets/templates/spec.md)交付，建議依「目的與範圍、行為與規則、責任與契約、適用品質要求、驗收情境」閱讀。內容可合併，無用途的章節不保留；重要條件、失敗後果與責任不可因精簡省略。

| 文件類型 | 何時需要 |
| --- | --- |
| Feature Spec | 行為、規則、必要設計與驗收的主要交付文件 |
| [Feature Design](assets/templates/design.md) | 責任互動、交易或重要取捨需詳細展開，或使用者指定分開交付 |
| [System Context](assets/templates/system-context.md) | 多個功能共用背景、術語、責任邊界及規則 |
| [Module Catalog](assets/templates/module-catalog.md) | 需要重用模組能力與選用依據 |
| [Module Contract](assets/templates/module-contract.md) | 共用操作缺少足夠契約；已有定義直接引用 |

- 功能參數來源、轉換及結果用途留在 Spec；設計已拆分時歸 Design，擇一維護。
- 已有完整操作契約時，只補使用限制與功能差異，不重抄欄位表。
- 規則先用清楚名稱；跨文件追溯需要時才加識別碼，既有編碼保留。
- 既有規格沿用原結構。規格完成不代表自動開發；開發獲授權後，以已確認 BDD 銜接 TDD（測試驅動開發）與實際入口驗證。

## 生成示例

以下為虛構的簡單查詢規格節錄，用來展示同一文件如何交代行為與必要設計；政策不代表銀行共用規範。完整欄位與錯誤型別由專案的 BatchQuery v1 契約定義，實際交付須連到該契約的真實位置。

### 批次結果查詢

**目的與範圍**

企業經辦查詢已提交批次的目前結果，以安排核對。本功能到查詢結果交付為止。

**行為與規則**

- 已登入經辦從查詢入口提供 UUID 批次識別。
- 先檢查 result:read 權限，缺少時回 403；具權限者只能查詢所屬企業，跨企業與不存在均回 404。
- 成功回傳同一時點的狀態、成功數與失敗數；查詢完成不代表批次已終局。
- 儲存不可用回 503，不自動重試。所有查詢都不修改批次或觸發重跑。

**責任與契約**

- 查詢入口傳遞已驗證的登入脈絡及批次識別，呈現結果。
- BatchQuery.getResult 擁有權限與企業範圍判定；企業識別取自登入脈絡，不採用請求自行填入的值。
- 輸入、快照及錯誤型別沿用 BatchQuery v1 契約；本功能將 Unavailable 對應為 HTTP 503。

**驗收情境：跨企業不揭露資料**

- **Given** 曙光企業經辦具查詢權限，目標批次屬於另一企業。
- **When** 從查詢入口要求該批次結果。
- **Then** 回 404，不揭露狀態與筆數，批次資料維持不變。

本節僅展示一個情境，完整交付仍需涵蓋已確認的正常、拒絕及其他重要失敗結果。

## 文件導覽

| 路徑 | 職責 |
| --- | --- |
| [SKILL.md](SKILL.md) | 任務範圍、分析流程、參考文件載入條件與模板選用 |
| [agents/openai.yaml](agents/openai.yaml) | 顯示名稱、起始提示與明確呼叫設定 |
| [references/authoring-rules.md](references/authoring-rules.md) | 完整性、可讀性、去重、來源、BDD 與開發交接判準 |
| [references/design-rules.md](references/design-rules.md) | 責任、契約、方法選用與效能設計 |
| [references/batch-processing.md](references/batch-processing.md) | 批次與檔案處理的專門檢查項目 |
| `assets/templates/` | 功能規格及按需文件的起始結構 |
| [evals/cases.md](evals/cases.md) | 維護時使用的行為評估案例 |
| README.md | 使用說明、文件索引及設計來源 |

使用者提供需求或文件即可；Skill 按需載入準則及模板。BDD（行為驅動開發）以 Given／When／Then 描述驗收情境，實際測試結果另行記錄。

## 驗證狀態

本次改版的檢查範圍及結果見[改版驗證紀錄](evals/redesign-results.md)。歷史紀錄保留於[評估案例](evals/cases.md#執行紀錄)，不能當作新版全部通過的證據。

規格生成、獨立讀者理解、實作測試與效能量測分別記錄；模型評估不代替真人閱讀或正式環境驗收。

## 設計來源

本 Skill 參考下列方法，並保留適合規格工作的部分；使用時不依賴這些工具。

<details>
<summary>方法來源與採用範圍</summary>

| 官方來源 | 採用的方法與本 Skill 對應 |
| --- | --- |
| [Cucumber BDD](https://cucumber.io/docs/bdd/)、[TDD](https://martinfowler.com/bliki/TestDrivenDevelopment.html) | 以具體情境釐清需求，將已確認行為交接給測試與實作；規格任務不自動啟動開發 |
| [Agent Skills specification](https://agentskills.io/specification) | SKILL.md 的 name／description、相對資源引用、逐步揭露；主檔導航、references 規則、assets 模板 |
| [Codex Skills](https://learn.chatgpt.com/docs/build-skills) | 專案 Skill 位置、openai.yaml 與明確觸發設定 |
| [OpenSpec 專案](https://github.com/Fission-AI/OpenSpec)、[Project configuration](https://openspec.dev/docs/project-config)、[Schemas](https://openspec.dev/docs/customize-schemas) | 共用背景、文件專屬規則、可客製模板與 spec／design 分工，用於共用背景、references 與按需拆分的文件 |
| [Spec Kit 官方說明](https://github.com/github/spec-kit) | 共用原則與「先 what／why，再 how」的責任分離，用於區分行為與必要設計，不要求各自獨立成檔 |
| [arc42 overview](https://arc42.org/overview/)、[Building Block View](https://docs.arc42.org/section-5/) | 黑箱責任與重要模組逐層展開，配合 Runtime View、Crosscutting Concepts、Architecture Decisions，落在目錄與必要設計檢查 |
| [Context Mapper](https://contextmapper.org/)、[Bounded Context](https://contextmapper.org/docs/bounded-context/)、[Context Map](https://contextmapper.org/docs/context-map/) | 術語／模型適用邊界、責任及上下文整合關係，按業務複雜度用於背景與模型分析 |

模板與規則依本專案需求撰寫，未複製上游完整模板。

</details>

README 編排參考 [reverse-domain-discovery](https://github.com/ivyliu1201/reverse-domain-discovery)。
