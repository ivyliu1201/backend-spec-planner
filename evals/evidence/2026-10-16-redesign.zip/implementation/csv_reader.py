﻿"""Read and validate payment records without changing the source file."""

import csv


def iter_records(path):
    with open(path, encoding="utf-8", newline="") as source:
        header = source.readline()
        if header not in ("status,amount_minor", "status,amount_minor\n", "status,amount_minor\r\n"):
            raise ValueError("Invalid header")
        try:
            for row in csv.reader(source):
                if len(row) != 2:
                    raise ValueError("Expected two fields")
                status, amount = row
                if status not in ("APPROVED", "DECLINED", "PENDING"):
                    raise ValueError("Invalid status")
                if not amount.isascii() or not amount.isdigit():
                    raise ValueError("Invalid amount")
                yield status, int(amount)
        except csv.Error as error:
            raise ValueError("Invalid CSV") from error
