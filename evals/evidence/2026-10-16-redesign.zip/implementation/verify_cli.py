﻿"""Execute real CLI cases and the two performance BDD scenarios."""

import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

from test_cases import HEADER, INVALID_CASES, SUCCESS_CASES, expected

ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / "change-test-artifacts"
ARTIFACTS.mkdir(exist_ok=True)


def digest(path):
    if not path.is_file():
        return None
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def invoke(command, path, result):
    before = digest(path)
    completed = subprocess.run(command, cwd=ROOT, capture_output=True)
    after = digest(path)
    stdout = completed.stdout.decode("utf-8")
    stderr = completed.stderr.decode("utf-8")
    record = {
        "command": command,
        "exit_code": completed.returncode,
        "stdout": stdout,
        "stderr": stderr,
        "source_sha256_before": before,
        "source_sha256_after": after,
    }
    assert before == after, record
    if result is None:
        assert completed.returncode == 2, record
        assert stdout == "", record
        assert stderr in ("INVALID_INPUT\n", "INVALID_INPUT\r\n"), record
    else:
        assert completed.returncode == 0, record
        assert stderr == "", record
        assert stdout.endswith("\n") and len(stdout.splitlines()) == 1, record
        actual = json.loads(stdout)
        assert actual == result, record
        assert len(actual) == 5 and all(type(value) is int for value in actual.values()), record
    record["passed"] = True
    return record


report = {"python": sys.version, "platform": platform.platform(), "cases": [], "performance": []}
for name, payload, result in SUCCESS_CASES:
    path = ARTIFACTS / (name + ".csv")
    path.write_bytes(payload)
    record = invoke([sys.executable, "main.py", str(path)], path, result)
    record["case"] = name
    report["cases"].append(record)

for name, payload in INVALID_CASES:
    path = ARTIFACTS / (name + ".csv")
    path.write_bytes(payload)
    record = invoke([sys.executable, "main.py", str(path)], path, None)
    record["case"] = name
    report["cases"].append(record)

missing = ARTIFACTS / "nonexistent.csv"
assert not missing.exists(), "Missing-file fixture must not exist"
for name, path in (("nonexistent_file", missing), ("unreadable_directory", ARTIFACTS)):
    record = invoke([sys.executable, "main.py", str(path)], path, None)
    record["case"] = name
    report["cases"].append(record)

for count, result in ((1000, expected(1000, 334, 333, 333, 33400)), (200000, expected(200000, 66667, 66667, 66666, 6666700))):
    path = ARTIFACTS / ("performance_" + str(count) + ".csv")
    rows = (b"APPROVED,100\n", b"DECLINED,200\n", b"PENDING,300\n")
    with path.open("wb") as output:
        output.write(HEADER)
        for index in range(count):
            output.write(rows[index % 3])
    metrics_path = ARTIFACTS / ("metrics_" + str(count) + ".json")
    command = [sys.executable, "measure_entry.py", str(path), str(metrics_path)]
    record = invoke(command, path, result)
    record.update(json.loads(metrics_path.read_text(encoding="utf-8")))
    record["row_count"] = count
    report["performance"].append(record)

small, large = report["performance"]
assert small["python"] == large["python"] and small["executable"] == large["executable"]
report["peak_increment_bytes"] = large["peak_bytes"] - small["peak_bytes"]
report["peak_increment_limit_bytes"] = 8388608
assert report["peak_increment_bytes"] <= report["peak_increment_limit_bytes"], report["performance"]
report["passed"] = True
(ROOT / "change-cli-evidence.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
lines = ["$ python verify_cli.py", "Python: " + sys.version, "Platform: " + report["platform"]]
for record in report["cases"]:
    lines.append("PASS " + record["case"] + " exit=" + str(record["exit_code"]) + " stdout=" + repr(record["stdout"]) + " stderr=" + repr(record["stderr"]) + " source_unchanged=True")
for record in report["performance"]:
    lines.append("PASS rows=" + str(record["row_count"]) + " peak_bytes=" + str(record["peak_bytes"]) + " elapsed_seconds=" + str(record["elapsed_seconds"]) + " stdout=" + repr(record["stdout"]) + " stderr=" + repr(record["stderr"]) + " source_unchanged=True")
lines.append("peak_increment_bytes=" + str(report["peak_increment_bytes"]) + " <= 8388608")
lines.append("PASS " + str(len(report["cases"])) + " CLI cases and 2 fresh-process measurements; exit_code=0")
output = "\n".join(lines) + "\n"
(ROOT / "change-cli.log").write_text(output, encoding="utf-8")
print(output, end="")
