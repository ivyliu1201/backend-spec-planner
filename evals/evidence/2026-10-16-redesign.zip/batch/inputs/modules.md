# 能力目錄

以下為本案例既有模組；功能不可改變其責任或契約。

- BatchCoordinator：execute(batchId) 啟動，resume(batchId) 恢復；協調規則見 requirements.md。它負責業務判斷及選擇傳入操作的值。
- Debit：debit 與 lookup 是本功能唯一的扣款與查證能力；契約見 contracts.md#debit。
- BatchStore：提供 load、beginItem、saveProgress、wait、finish 及執行排他；契約見 contracts.md#batchstore。沒有扣款能力。