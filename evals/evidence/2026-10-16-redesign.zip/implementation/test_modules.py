﻿"""Module contracts from docs/spec.md; no third-party dependencies."""

import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import csv_reader
import main
import summary
from test_cases import HEADER, INVALID_CASES, SUCCESS_CASES, expected


class FileCases(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "input.csv"

    def write(self, data):
        self.path.write_bytes(data)
        return self.path


class ReaderTests(FileCases):
    def test_valid_record_values_and_source_unchanged(self):
        payload = HEADER + b'"APPROVED","100"\nDECLINED,0200\nPENDING,0\n'
        self.write(payload)
        self.assertEqual(list(csv_reader.iter_records(self.path)), [("APPROVED", 100), ("DECLINED", 200), ("PENDING", 0)])
        self.assertEqual(self.path.read_bytes(), payload)

    def test_valid_cases(self):
        for name, payload, result in SUCCESS_CASES:
            with self.subTest(case=name):
                self.write(payload)
                records = list(csv_reader.iter_records(self.path))
                self.assertEqual(len(records), result["totalCount"])
                for status, amount in records:
                    self.assertIn(status, ("APPROVED", "DECLINED", "PENDING"))
                    self.assertIs(type(amount), int)
                    self.assertGreaterEqual(amount, 0)
                self.assertEqual(self.path.read_bytes(), payload)

    def test_invalid_cases_raise_value_error(self):
        for name, payload in INVALID_CASES:
            with self.subTest(case=name):
                self.write(payload)
                with self.assertRaises(ValueError):
                    list(csv_reader.iter_records(self.path))
                self.assertEqual(self.path.read_bytes(), payload)

    def test_missing_file_raises_os_error(self):
        with self.assertRaises(OSError):
            list(csv_reader.iter_records(self.path))

    def test_late_error_is_raised_during_iteration(self):
        self.write(HEADER + b"APPROVED,100\nUNKNOWN,200\n")
        records = iter(csv_reader.iter_records(self.path))
        self.assertEqual(next(records, None), ("APPROVED", 100))
        with self.assertRaises(ValueError):
            next(records)


class SummaryTests(unittest.TestCase):
    def test_empty_source(self):
        self.assertEqual(summary.summarize(iter(())), expected(0, 0, 0, 0, 0))

    def test_counts_and_approved_amount(self):
        records = [("APPROVED", 0), ("DECLINED", 9000), ("PENDING", 7000), ("APPROVED", 1)]
        original = records.copy()
        self.assertEqual(summary.summarize(iter(records)), expected(4, 2, 1, 1, 0))
        self.assertEqual(records, original)

    def test_approved_amount_threshold_counts_every_approval(self):
        records = (("APPROVED", amount) for amount in (0, 99, 100, 101))
        result = summary.summarize(records)
        self.assertEqual(result["approvedAmountMinor"], 201)
        self.assertEqual(result, expected(4, 4, 0, 0, 201))

    def test_single_use_source(self):
        class SingleUse:
            def __init__(self):
                self.visits = 0
                self.records = iter((("APPROVED", 100), ("DECLINED", 200), ("PENDING", 300)))

            def __iter__(self):
                self.visits += 1
                if self.visits > 1:
                    raise AssertionError("Source iterated more than once")
                return self

            def __next__(self):
                return next(self.records)

        records = SingleUse()
        self.assertEqual(summary.summarize(records), expected(3, 1, 1, 1, 100))
        self.assertEqual(records.visits, 1)

    def test_source_failure_propagates(self):
        def records():
            yield "APPROVED", 100
            raise ValueError("invalid later record")
        with self.assertRaisesRegex(ValueError, "invalid later record"):
            summary.summarize(records())

    def test_summary_has_no_output(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            summary.summarize(iter((("APPROVED", 100),)))
        self.assertEqual((stdout.getvalue(), stderr.getvalue()), ("", ""))


class MainTests(unittest.TestCase):
    def invoke(self, path):
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = main.main(path)
        return code, stdout.getvalue(), stderr.getvalue()

    def test_delegates_and_serializes_only_completed_summary(self):
        records = iter((("APPROVED", 1),))
        result = expected(1, 1, 0, 0, 0)
        with mock.patch.object(csv_reader, "iter_records", return_value=records) as reader, mock.patch.object(summary, "summarize", return_value=result) as summarizer:
            code, stdout, stderr = self.invoke("input.csv")
        reader.assert_called_once_with("input.csv")
        summarizer.assert_called_once_with(records)
        import json
        self.assertEqual(json.loads(stdout), result)
        self.assertEqual((code, stderr), (0, ""))
        self.assertTrue(stdout.endswith("\n"))
        self.assertEqual(len(stdout.splitlines()), 1)

    def test_acquisition_errors_are_converted(self):
        for error in (ValueError("invalid"), OSError("unreadable")):
            with self.subTest(error=type(error).__name__), mock.patch.object(csv_reader, "iter_records", side_effect=error):
                self.assertEqual(self.invoke("input.csv"), (2, "", "INVALID_INPUT\n"))

    def test_iteration_errors_are_converted_without_partial_output(self):
        for error in (ValueError("invalid later"), OSError("read failed later")):
            def records():
                yield "APPROVED", 100
                raise error
            with self.subTest(error=type(error).__name__), mock.patch.object(csv_reader, "iter_records", return_value=records()):
                self.assertEqual(self.invoke("input.csv"), (2, "", "INVALID_INPUT\n"))


if __name__ == "__main__":
    unittest.main()
