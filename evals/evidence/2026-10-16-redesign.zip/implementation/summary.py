﻿"""Summarize a single traversal of validated payment records."""


def summarize(records):
    result = {
        "totalCount": 0,
        "approvedCount": 0,
        "declinedCount": 0,
        "pendingCount": 0,
        "approvedAmountMinor": 0,
    }
    for status, amount in records:
        result["totalCount"] += 1
        if status == "APPROVED":
            result["approvedCount"] += 1
            if amount >= 100:
                result["approvedAmountMinor"] += amount
        elif status == "DECLINED":
            result["declinedCount"] += 1
        else:
            result["pendingCount"] += 1
    return result
