# 既有契約

以下契約版本均為 v1，為虛構測試材料；本次不可修改。

## Debit

- debit(operationId, accountId, amountMinor, currency, retentionDays)：operationId 為非空字串、最多 128 字元；accountId 為非空字串；amountMinor 為正整數；currency 為 TWD；retentionDays 為 1 至 365 的整數。所有欄位必填。
- 同一 operationId 在保留期間內，且帳戶、金額與幣別相同時，重複呼叫沿用同一筆扣款及結果；內容不同回 Conflict，不執行新扣款。保留期間由首次受理起按 retentionDays × 24 小時計算，重複呼叫不延長。
- 成功回 Success（receiptId 為非空字串）；明確拒絕回 Declined（reason 為非空字串，未扣款）；Timeout 表示可能已扣款，結果未知。收到 Success 才能聲稱扣款成功。
- lookup(operationId)：唯讀；回 Success、Declined、Pending、NotFound、Expired 或 Unavailable。Success／Declined 定義同上；Pending 表示已受理但未終局；NotFound 只代表目前查無紀錄，不證明從未執行；Expired 表示防重紀錄已到期；Unavailable 表示無法查證。模組不自動重試。
- 本契約不保證跨模組交易；外部扣款不能由 BatchStore 回滾撤銷。

## BatchStore

- 入口既有的執行排他能力確保同批一次只有一個工作者；程序終止後由恢復工作者接手，無需自行新增鎖機制。
- load(batchId)：回同一時點的原始項目、各項目狀態與結果、operationId、retentionDays、檢查點及批次彙總；未找到回 BatchNotFound。原始項目不可變，操作意圖與占用均跨重啟保留。
- beginItem(batchId, itemId, operationId, retentionDays)：原子記錄操作意圖、將 PENDING 改為 IN_FLIGHT，並取得全系統 accountId 範圍的持久占用。既有終局項目回 AlreadyFinal；既有未終局項目回 ExistingIntent；帳戶被其他項目占用回 Busy；相同項目搭配不同操作意圖回 Conflict。只有首次取得意圖與占用的呼叫可進行 debit。
- saveProgress(batchId, itemId, result, checkpointSeq?)：result 為 Debit 的 Success 或 Declined，原子保存項目終局結果並釋放該帳戶占用。若傳入 checkpointSeq，同一交易更新檢查點；省略則不更新。重複保存相同結果無副作用，衝突結果回 Conflict。檢查點僅接受已連續終局的 seq。
- wait(batchId, itemId, reason)：持久化 UNKNOWN 與 WAITING_RECONCILIATION、目前原因，保留帳戶占用及既有終局結果，不推進檢查點。
- finish(batchId, status)：只在全部項目終局時保存協調者決定的終局狀態及按項目計算的筆數快照。
- 本地交易失敗不提交部分變更；不可用時回 StoreUnavailable。無法記錄外部結果時，既有 IN_FLIGHT 意圖與占用仍保留，供下次 resume 先查證。上述操作均不自動重試，也不呼叫 Debit。