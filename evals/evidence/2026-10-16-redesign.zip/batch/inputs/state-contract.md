﻿# BatchStore v1 狀態契約補充

補充既有 BatchStore v1 契約：markRunning(batchId) 是既有操作，由 BatchCoordinator 在 load 核對入口狀態後、任何項目處理或查證前呼叫。它將 READY 或 WAITING_RECONCILIATION 原子持久化為 RUNNING；已為 RUNNING 時無副作用，其他狀態回 Conflict。成功表示狀態已提交；StoreUnavailable 時不提交，本次停止，不能開始扣款或查證。此操作不修改項目、意圖、帳戶占用或檢查點，也不呼叫 Debit。
