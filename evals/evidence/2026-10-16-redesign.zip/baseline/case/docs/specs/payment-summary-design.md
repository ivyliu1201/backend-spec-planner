# 付款狀態統計：功能設計

## 設計依據

- 功能行為與驗收：[付款狀態統計規格](payment-summary-spec.md)，涵蓋 BR-PAY-001 至 BR-PAY-004、品質要求與 BDD-PAY-001 至 BDD-PAY-007。
- 既定介面及責任：[付款狀態統計需求](../../inputs/requirements.md#付款狀態統計) 中的 `csv_reader.iter_records(path)`、`summary.summarize(records)`、`main.py`。
- Python 3，僅標準函式庫；沿用已定的三個模組責任，不要求工廠、外掛、Repository 或其他模式。內部等價寫法保留彈性。
- 本設計只交付規格，不包含程式實作。

## 責任分工

三個模組為協作關係，依既定責任直接串接。

| 模組 | 責任 | 使用操作 | 選用依據 |
| --- | --- | --- | --- |
| `csv_reader` | 讀檔及驗證 BR-PAY-001 輸入格式，逐筆交付有效資料 | `iter_records(path)` | 檔案處理與輸入驗證的指定負責者 |
| `summary` | 執行 BR-PAY-002 統計規則，回傳完整結果 | `summarize(records)` | 統計規則的指定負責者；不讀檔、不輸出、不修改來源 |
| `main.py` | 取得指定路徑、協調呼叫、將輸入錯誤轉為 BR-PAY-003 命令列回應 | `python main.py input.csv` | 指定的外部入口；不得複製統計規則 |

BR-PAY-004 唯讀處理及逐筆處理的品質要求適用於整體流程。

## 執行流程

1. `main.py` 取得命令列提供的唯一檔案路徑，呼叫 `csv_reader.iter_records(path)`。
2. `main.py` 將紀錄來源直接交給 `summary.summarize(records)`。紀錄來源只允許走訪一次，不先收集成完整清單。
3. `csv_reader` 在讀取時驗證各紀錄，逐筆產生 `(status, amount_minor)`；`summary` 在同一趟走訪中累計五個結果。
4. `summary` 完成來源走訪後回傳完整結果物件，`main.py` 再將結果序列化為規定的 JSON 並輸出。
5. 檔案開啟、讀取或走訪途中出現輸入錯誤時，由 `main.py` 將錯誤轉為指定失敗回應，不輸出累計中的結果。錯誤處理範圍須涵蓋來源實際被走訪的期間，不能只包住建立紀錄來源的呼叫。

### 失敗處理

- `csv_reader.iter_records(path)` 以 `ValueError` 表示格式錯誤；檔案讀取錯誤可維持 `OSError`。編碼、表頭、資料欄位等錯誤分類依既定輸入驗證契約。
- `main.py` 將上述輸入錯誤統一轉為功能規格的 BR-PAY-003 回應。
- `summary` 不負責檔案驗證或命令列錯誤格式；來源走訪發生錯誤時，不能回傳部分成功結果。

## 資料對應

契約依據為[需求中的既定操作](../../inputs/requirements.md#付款狀態統計)。下表說明本功能如何提供參數與使用結果；CSV 格式、統計公式及 CLI 回應由功能規格定義。

| 操作與資料 | 資料來源或轉換 | 結果用途 |
| --- | --- | --- |
| `csv_reader.iter_records(path)` 的 `path` | 命令列指定的唯一檔案路徑 | 開啟與逐筆讀取指定 CSV |
| `iter_records` 產生的 `status` | 合法 CSV 紀錄第一欄，保留大小寫與內容，不去除空白 | 決定狀態筆數及是否加總金額 |
| `iter_records` 產生的 `amount_minor` | 驗證第二欄符合 ASCII 數字格式後，轉為非負整數；單位 TWD 分 | 供統計核准金額使用 |
| `summary.summarize(records)` 的 `records` | `iter_records` 提供的單次走訪有效紀錄來源，每筆為 `(status, amount_minor)` | 逐筆累計統計，不重讀或修改來源 |
| `summarize` 回傳的結果物件 | 功能規格「輸入、輸出與完成條件」定義的五個整數欄位 | `main.py` 直接序列化並交付完整成功結果 |

### 執行限制

- `csv_reader` 負責讀檔與驗證，`summary` 只消費有效紀錄與累計；維持責任界線，不在 `main.py` 重寫統計規則。
- 整條流程須維持逐筆消費，不以完整檔案或所有紀錄的集合保存中間資料；只保留完成本次統計所需的累計結果及當前處理資料。
- `summary.summarize(records)` 必須接受只能走訪一次的來源，不可依賴重複迭代、索引或來源長度。
- 對外結果必須等來源完整走訪成功後才輸出，確保後段錯誤沒有部分成功結果。
- 內部與回歸驗證應涵蓋讀檔驗證、單次走訪來源、純統計責任、錯誤傳遞及無副作用；最終從 CLI 執行功能規格所列 BDD，並依品質要求量測記憶體。
