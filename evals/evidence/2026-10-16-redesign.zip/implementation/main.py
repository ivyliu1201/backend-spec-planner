﻿"""Command-line coordination for payment summaries."""

import json
import sys

import csv_reader
import summary


def main(path):
    try:
        result = summary.summarize(csv_reader.iter_records(path))
    except (ValueError, OSError):
        print("INVALID_INPUT", file=sys.stderr)
        return 2
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1]))
