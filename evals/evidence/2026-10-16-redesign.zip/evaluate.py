
from pathlib import Path
import hashlib, json, subprocess, sys, tempfile, time, platform
project = Path(sys.argv[1]).resolve()
changed = '--changed' in sys.argv[2:]
work = Path(tempfile.mkdtemp(prefix='acceptance-', dir=project.parent))
results = []
def expected(n, a, d, p, amount):
    return dict(totalCount=n, approvedCount=a, declinedCount=d, pendingCount=p, approvedAmountMinor=amount)
zero = expected(0,0,0,0,0)
cases = [
('mixed', b'status,amount_minor\nAPPROVED,100\nDECLINED,200\nPENDING,300\n', expected(3,1,1,1,100)),
('header-only',b'status,amount_minor\n',zero),
('zero-leading',b'status,amount_minor\nAPPROVED,0\nAPPROVED,001\n',expected(2,2,0,0,0 if changed else 1)),
('crlf',b'status,amount_minor\r\nAPPROVED,100\r\n',expected(1,1,0,0,100)),
('quoted',b'status,amount_minor\n"APPROVED","100"\n',expected(1,1,0,0,100)),
('threshold',b'status,amount_minor\nAPPROVED,0\nAPPROVED,99\nAPPROVED,100\nAPPROVED,101\n',expected(4,4,0,0,201 if changed else 300)),
('empty',b'',None),
('wrong-header',b'amount_minor,status\n',None),
('bom',b'\xef\xbb\xbfstatus,amount_minor\n',None),
('lowercase',b'status,amount_minor\napproved,100\n',None),
('negative',b'status,amount_minor\nAPPROVED,-1\n',None),
('plus',b'status,amount_minor\nAPPROVED,+1\n',None),
('decimal',b'status,amount_minor\nAPPROVED,1.0\n',None),
('space',b'status,amount_minor\nAPPROVED, 1\n',None),
('unicode-digit','status,amount_minor\nAPPROVED,１２\n'.encode(),None),
('empty-amount',b'status,amount_minor\nAPPROVED,\n',None),
('missing-field',b'status,amount_minor\nAPPROVED\n',None),
('extra-field',b'status,amount_minor\nAPPROVED,1,x\n',None),
('blank-record',b'status,amount_minor\n\n',None),
('invalid-utf8',b'status,amount_minor\nAPPROVED,\xff\n',None),
('late-invalid',b'status,amount_minor\nAPPROVED,100\nUNKNOWN,1\n',None)]
def run_case(name, source, output):
    before = hashlib.sha256(source.read_bytes()).hexdigest() if source.is_file() else None
    proc = subprocess.run([sys.executable,'main.py',str(source)],cwd=project,capture_output=True,timeout=30)
    checks = []
    if output is None:
        checks.extend([proc.returncode == 2,proc.stdout == b'',proc.stderr == b'INVALID_INPUT\n' or proc.stderr == b'INVALID_INPUT\r\n'])
    else:
        try:
            actual = json.loads(proc.stdout)
            checks.extend([actual == output, all(type(v) is int for v in actual.values()), proc.stdout.endswith(b'\n')])
        except Exception:
            checks.append(False)
        checks.extend([proc.returncode == 0,proc.stderr == b''])
    if before:
        checks.append(hashlib.sha256(source.read_bytes()).hexdigest()==before)
    results.append(dict(name=name,passed=all(checks),exit_code=proc.returncode,stdout=proc.stdout.decode('utf-8','replace'),stderr=proc.stderr.decode('utf-8','replace')))
for name,data,output in cases:
    source = work/(name+'.csv')
    source.write_bytes(data)
    run_case(name,source,output)
run_case('missing-file',work/'absent.csv',None)
run_case('directory',work,None)
onepass = r'''
from summary import summarize
class Source:
    def __init__(self): self.used=False
    def __iter__(self):
        if self.used: raise RuntimeError('second traversal')
        self.used=True
        yield ('APPROVED',100)
        yield ('DECLINED',1)
        yield ('PENDING',2)
assert summarize(Source()) == dict(totalCount=3,approvedCount=1,declinedCount=1,pendingCount=1,approvedAmountMinor=100)
'''
proc = subprocess.run([sys.executable,'-c',onepass],cwd=project,capture_output=True)
results.append(dict(name='single-pass-contract',passed=proc.returncode==0,stderr=proc.stderr.decode('utf-8','replace')))
probe = r'''
import sys, runpy, tracemalloc, time, json
from pathlib import Path
target=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(target.parent))
sys.argv=[str(target),sys.argv[2]]
tracemalloc.start()
start=time.perf_counter()
code=0
try:
    runpy.run_path(str(target),run_name='__main__')
except SystemExit as exc:
    code=exc.code or 0
elapsed=time.perf_counter()-start
_,peak=tracemalloc.get_traced_memory()
print(json.dumps(dict(peak_bytes=peak,elapsed_seconds=elapsed)),file=sys.stderr)
raise SystemExit(code)
'''
metrics=[]
for n in [1000,200000]:
    path=work/f'load-{n}.csv'
    rows=[b'APPROVED,100\n',b'DECLINED,200\n',b'PENDING,300\n']
    with path.open('wb') as f:
        f.write(b'status,amount_minor\n')
        for i in range(n): f.write(rows[i%3])
    proc=subprocess.run([sys.executable,'-c',probe,str(project/'main.py'),str(path)],cwd=project,capture_output=True,timeout=120)
    try:
        metric=json.loads(proc.stderr)
        actual=json.loads(proc.stdout)
        a=(n+2)//3; d=(n+1)//3; p=n//3
        ok=proc.returncode==0 and actual==expected(n,a,d,p,a*100)
        metric.update(records=n,output_correct=ok)
    except Exception:
        metric=dict(records=n,output_correct=False,stderr=proc.stderr.decode('utf-8','replace'))
    metrics.append(metric)
memory_ok=all(m['output_correct'] for m in metrics)
delta=None
if memory_ok:
    delta=metrics[1]['peak_bytes']-metrics[0]['peak_bytes']
    memory_ok=delta <= 8*1024*1024
results.append(dict(name='memory-budget',passed=memory_ok,delta_bytes=delta))
report=dict(project=str(project),changed=changed,python=sys.version,platform=platform.platform(),checks=results,measurements=metrics,passed=all(x['passed'] for x in results))
(work/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(report=str(work/'report.json'),passed=report['passed'],checks=len(results),failed=[x for x in results if not x['passed']],measurements=metrics,delta_bytes=delta),ensure_ascii=False))
raise SystemExit(not report['passed'])
