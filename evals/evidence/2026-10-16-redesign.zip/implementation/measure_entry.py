﻿"""Measure one fresh process executing main.py; fixtures are prepared separately."""

import json
from pathlib import Path
import runpy
import sys
import time
import tracemalloc

entry = Path(__file__).with_name("main.py")
input_path, metrics_path = sys.argv[1:]
sys.argv = [str(entry), input_path]
tracemalloc.start()
started = time.perf_counter()
try:
    runpy.run_path(str(entry), run_name="__main__")
except SystemExit as error:
    exit_code = error.code
else:
    exit_code = 0
elapsed = time.perf_counter() - started
_, peak = tracemalloc.get_traced_memory()
tracemalloc.stop()
Path(metrics_path).write_text(json.dumps({"peak_bytes": peak, "elapsed_seconds": elapsed, "python": sys.version, "executable": sys.executable}), encoding="utf-8")
raise SystemExit(exit_code)
