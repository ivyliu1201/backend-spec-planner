﻿# 批次付款執行與中斷續作設計

## 設計依據

- 業務行為、停止條件與驗收以 [Spec](spec.md)為準。
- 模組依 [能力目錄](../inputs/modules.md)協作；Debit 與 BatchStore 操作沿用 [v1 契約](../inputs/contracts.md)。
- `markRunning(batchId)` 沿用 [BatchStore v1 狀態契約補充](../inputs/state-contract.md)，屬既有能力的文件補充。
- 原始項目、資料保存及功能邊界依 [批次需求](../inputs/requirements.md)。不改變既有責任、公開操作或項目內容。

## 責任分工

| 模組 | 本功能責任 | 依賴與修改邊界 |
| --- | --- | --- |
| BatchCoordinator | 驗證入口狀態；選擇參數；決定處理順序、查證、停止、項目結果對應、檢查點及批次彙總。 | 呼叫 Debit 與 BatchStore；透過既有儲存操作持久化，不自行實作扣款或繞過儲存契約。 |
| Debit | 執行扣款、依 operationId 提供防重及查證結果。 | 不決定批次順序、彙總、檢查點或下一步；外部扣款無 BatchStore 回滾保證。 |
| BatchStore | 保存原始資料、意圖、項目與批次狀態；提供原子交易、同批執行排他與全系統帳戶占用。 | 按既有操作執行資料變更，不選擇業務政策、不呼叫 Debit。 |

此功能採既有協調者直接協作；能力目錄中 Debit 是唯一扣款與查證能力，BatchStore 與其互補。沒有替代扣款模組、失敗切換或新增分層的需求。

## 執行流程

### 入口處理

1. 進入既有同批執行排他範圍，由 BatchCoordinator 呼叫 `BatchStore.load(batchId)`，取得同一時點的項目、意圖、進度與批次狀態。
2. 依 [Spec：入口與回應](spec.md#入口與回應)判定終局重用、批次不存在及入口狀態不合法；這些情況不呼叫 `markRunning` 或 Debit。
3. 合法非終局入口呼叫 `markRunning(batchId)`。成功提交後才可處理項目或查證；`Conflict` 或 `StoreUnavailable` 立即停止，不開始扣款或查證。
4. 以已載入的項目狀態核對檢查點，依 `seq` 找到下一個未終局項目；終局項目只重用已保存結果。
5. 依下節處理該項。所有項目終局後，由 BatchCoordinator 按 [Spec：進度與彙總](spec.md#進度與彙總)算出筆數及狀態，呼叫 `finish(batchId, status)`；成功提交後回傳終局快照。
6. 任一分支停止時回傳已確認快照與原因。儲存不可用時，不將未提交的改變加入持久化結果或聲稱批次已終局。

### 項目處理

| 項目或操作結果 | BatchCoordinator 的下一步 |
| --- | --- |
| `SUCCEEDED` 或 `FAILED` | 跳過扣款與查證，移至下一項。 |
| `PENDING` | 依資料對應組成意圖，呼叫 `beginItem`。 |
| `beginItem` 首次成功取得意圖與占用 | 提交完成後，使用相同參數呼叫一次 `debit`。 |
| `beginItem` 回 `AlreadyFinal` | 不扣款，透過 `load` 取得已保存結果並核對進度。 |
| `beginItem` 回 `ExistingIntent` | 不扣款，透過 `load` 取得原意圖與項目狀態，依既有意圖查證分支處理。 |
| 已有 `IN_FLIGHT` 或 `UNKNOWN` | 使用已保存 `operationId` 呼叫一次 `lookup`；不能先重新建立意圖或扣款。 |
| `debit` 或 `lookup` 回 `Success`／`Declined` | 算出納入本項結果後的最後連續終局 seq，呼叫 `saveProgress`；成功提交後才能處理下一項。 |
| `debit` 回 `Timeout` | 呼叫 `wait` 保存等待狀態及逾時原因，隨後停止。 |
| `lookup` 回 `Pending`／`NotFound`／`Expired`／`Unavailable` | 呼叫 `wait` 保存對應原因，隨後停止；NotFound 與 Expired 的原因包含人工核對需求。 |
| 任一適用操作回 `Busy`／`Conflict`／`StoreUnavailable` | 按 Spec 停止並交付原因，不自動重試；不再發出後續扣款。 |

- `Success` 與 `Declined` 直接使用 Debit 回傳內容保存；不得由逾時、NotFound 或本地狀態自行合成成功／拒絕。
- `load` 在 `AlreadyFinal`／`ExistingIntent` 後用於讀取既有資料，不是重新扣款或重試失敗操作；其失敗同樣停止。
- 一次 `resume` 對該待查項目最多一次 `lookup`。查證得到終局且提交成功後，後續 `PENDING` 項目可正常扣款；後續項目若逾時，本次呼叫就停止，不立即接著查證。
- `saveProgress`、`wait` 或 `finish` 失敗時，不嘗試以其他寫入掩蓋原失敗，也不繼續下一項；保留原已提交狀態供後續恢復。

### 狀態持久化

每項狀態變更均由既有操作完成，業務判斷仍由 BatchCoordinator 負責：

| 狀態或資料變更 | 操作與保證來源 |
| --- | --- |
| READY／WAITING_RECONCILIATION 轉 RUNNING；RUNNING 重入無副作用 | `markRunning`，見 [狀態契約補充](../inputs/state-contract.md)。 |
| PENDING 轉 IN_FLIGHT，保存意圖並取得帳戶占用 | `beginItem`，見 [BatchStore v1](../inputs/contracts.md#batchstore)。 |
| 保存 SUCCEEDED／FAILED 與結果，釋放占用並更新檢查點 | `saveProgress`，本功能每次都傳入 `checkpointSeq`。 |
| 保存 UNKNOWN、WAITING_RECONCILIATION 及原因 | `wait`，保留占用及既有終局結果，不推進檢查點。 |
| 保存批次終局與筆數快照 | `finish`，只在所有項目均終局時呼叫。 |

### 交易與恢復

- **執行起點**：`markRunning` 是獨立原子提交，不修改項目、意圖、占用或檢查點。它成功後才進行外部呼叫，讓中斷的批次可由 `resume` 接手。
- **意圖提交**：`beginItem` 將意圖、`IN_FLIGHT` 與全系統 `accountId` 占用一起提交。只有首次成功取得意圖與占用的呼叫可扣款；既有未終局意圖只能查證。
- **結果提交**：每次 `saveProgress` 都傳入 Debit 終局結果及 BatchCoordinator 算出的最後連續終局 `seq`；結果、占用釋放、檢查點同交易提交並同時可見。失敗時三者均不提交。
- **外部扣款**：發生於意圖提交之後、結果提交之前，不包在 BatchStore 的本地交易內；既有契約不提供跨模組原子交易或外部撤銷。
- **等待提交**：`wait` 保存未知狀態與原因，保留意圖、占用及先前結果。寫入失敗時不偽稱已等待，依原持久化狀態恢復。
- **批次終局**：`finish` 在項目提交之後執行；若中斷或終局保存失敗，項目結果仍有效，下次恢復重算並完成批次終局，不重扣。

| 中斷位置 | 持久化證據 | 下一次合法入口的處理 |
| --- | --- | --- |
| markRunning 提交前 | 原批次狀態未變。 | 依原狀態選 execute 或 resume；先完成 markRunning。 |
| markRunning 提交後、beginItem 提交前 | RUNNING，該項仍 PENDING，沒有此次新意圖與占用。 | resume 對該項正常 beginItem；首次成功取得後才可扣款。 |
| beginItem 提交後、debit 前 | IN_FLIGHT、原意圖與占用。 | resume 先 lookup；即使回 NotFound 也等待人工核對，不重扣。 |
| 外部可能已完成、本地尚未提交結果 | 原 IN_FLIGHT／UNKNOWN 與占用仍在。 | resume 先 lookup；有終局結果才保存，其他結果等待。 |
| saveProgress 提交後、處理下一項前 | 終局結果、占用釋放與檢查點已一起提交。 | resume 核對項目後跳過該項，處理下一項。 |
| 所有項目終局、finish 尚未提交 | 所有項目結果已保存，批次尚非終局。 | resume 不呼叫 Debit，重算彙總後 finish。 |

同批互斥直接使用既有入口能力；跨批依 `beginItem` 的持久帳戶占用避免同帳戶重疊扣款。工作者終止不釋放未確定結果的占用；只有終局結果提交能釋放。不同帳戶的不同批次可並行，不改為同批平行處理。

## 資料對應

欄位型別、必填、回應內容及各操作限制引用 [Debit v1](../inputs/contracts.md#debit)、[BatchStore v1](../inputs/contracts.md#batchstore)與 [markRunning 補充](../inputs/state-contract.md)，不另建重複契約。以下是本功能選值及使用方式。

### 操作意圖

| 值 | 來源與規則 |
| --- | --- |
| `batchId` | 入口傳入的既有批次 UUID；以 load 的批次及原始項目為處理範圍。 |
| `itemId` | load 取得的原始項目 UUID。 |
| `operationId` | BatchCoordinator 以既有 `batchId`、冒號、既有 `itemId` 串接為 `batchId:itemId`；不加前綴、執行次數或新 UUID。建立意圖時保存，重啟與查證均沿用持久化相同值，不重新產生。 |
| `retentionDays` | BatchCoordinator 固定選 `30`，隨意圖保存；後續沿用原值，不因重啟或重複呼叫重設期限。 |
| `accountId` | load 的原始項目值；也是 beginItem 所取得占用的帳戶範圍。 |
| `amountMinor` | load 的原始正整數金額；沿用契約單位，不換算或四捨五入。 |
| `currency` | 原始項目的 `TWD`，原樣傳入。 |

- `beginItem(batchId, itemId, operationId, retentionDays)` 使用上表識別與保存政策；BatchStore 不替協調者選擇識別或期限。
- 首次成功取得意圖與占用後，`debit(operationId, accountId, amountMinor, currency, retentionDays)` 使用該筆已提交意圖與原始項目，所有必填參數都有來源。
- `lookup(operationId)` 只使用持久化原值；不以查證次數、批次重啟次數或新 UUID 代替。
- Debit 防重保留期間依契約由首次受理起算；本功能不新增本地期限重設、延長或到期後重送機制。

### 結果與進度

| 操作參數或回應 | 本功能對應 |
| --- | --- |
| `markRunning(batchId)` | 使用已通過入口狀態檢查的批次識別，在項目處理／查證前提交 RUNNING。 |
| `saveProgress` 的 `result` | Debit 原 `Success` 或 `Declined`，分別對應 SUCCEEDED 或 FAILED，保留 receiptId 或 reason。 |
| `saveProgress` 的 `checkpointSeq` | 以持久化項目終局狀態加上本次要提交的終局結果，計算最後連續終局 seq；每次必傳，不只取目前列號。 |
| `wait` 的 `reason` | 實際扣款逾時或查證回應；NotFound／Expired 加入人工核對原因，不偽稱未扣款。 |
| `finish` 的 `status` | BatchCoordinator 依全部項目終局結果決定，對應表見 Spec。 |
| 對外筆數快照 | 由 BatchCoordinator 按項目結果計數；終局透過 finish 保存。呼叫及查證次數不作業務筆數。 |

## 品質設計

- 原始資料載入、交易、排他及占用均使用既有 BatchStore；不新增依賴、鎖表、通用框架或自動重試。
- 同批依序執行，外部等待不構成本地跨模組交易；帳戶占用則跨重啟保留，避免尚未確認結果時重複扣款。
- `NotFound` 即使可能來自意圖已提交但尚未扣款，也不能證明從未執行；維持人工核對會暫停後續項目及占用帳戶，這是已選定的正確性限制。
- 既有 `90` 天工作資料保存與 `30` 天 Debit 防重保留各依其來源執行，不以較長的工作資料保存期延長外部保證。
- 驗收入口與具體情境見 [Spec：驗收情境](spec.md#驗收情境)。目前交付為規格文件，未實作產品、未執行單元／整合測試，也未量測效能；不推定測試命令或增加工具依賴。
