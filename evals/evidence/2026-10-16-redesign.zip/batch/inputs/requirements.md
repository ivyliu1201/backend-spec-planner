# 批次需求

以下是虛構評估資料，政策僅用於本案例。已知需求如下，最後列出的四項決策尚缺答案。

- 功能供既有內部批次工作者執行付款及中斷續作；入口為 BatchCoordinator.execute(batchId) 與 resume(batchId)。原始檔已完成格式、金額及授權驗證，批次已受理為 READY。本功能從執行開始，到終局或交付暫停原因結束；不含上傳、人工更正及排程頻率。
- 批次與項目均使用既有 UUID；每批至少一筆，項目含不重複 itemId、連續 seq、accountId、正整數 amountMinor 及固定 TWD。原始項目受理後不可更改。
- BatchCoordinator 擁有流程、狀態轉換與彙總規則；Debit 擁有扣款及查證結果；BatchStore 只提供持久化、交易與執行排他保證。
- 同批逐筆依 seq 執行，終局項目不得再呼叫 debit。不同批可並行，但同帳戶的扣款未得到明確結果前，不得開始下一筆扣款。
- 每筆扣款前先持久化操作意圖，再呼叫 Debit.debit；成功記 SUCCEEDED，明確拒絕記 FAILED，兩者均可繼續下一筆。
- 逾時為結果不明，記 UNKNOWN，批次轉 WAITING_RECONCILIATION 並停止後續列，保留已成功及已失敗結果。不得以回滾當作已撤銷外部扣款。
- resume 遇 IN_FLIGHT 或 UNKNOWN 必須先 lookup；查得成功或明確拒絕後記錄相應結果，才繼續。Pending、Expired 或 Unavailable 均維持等待及帳戶占用，不重新扣款；Expired 另記人工核對原因。
- 本功能不自動重試 debit 或 lookup；一次 resume 對待查項目最多查證一次。尚未得到終局結果時，回傳目前快照與原因，供既有營運流程核對。
- 批次狀態為 READY、RUNNING、WAITING_RECONCILIATION、COMPLETED、COMPLETED_WITH_ERRORS、FAILED。全部項目終局時：全成功為 COMPLETED，全失敗為 FAILED，混合為 COMPLETED_WITH_ERRORS。
- 成功數、失敗數、未完成數分別按項目計算；PENDING、IN_FLIGHT、UNKNOWN 都算未完成。三者合計為總筆數，重試或查證次數不計入業務筆數。終局要求未完成數為零。
- 檢查點表示最後一個連續終局項目的 seq，不能越過未知結果。恢復需核對持久化項目狀態，跳過終局項目。
- execute 只接受 READY；resume 只接受 RUNNING 或 WAITING_RECONCILIATION。終局批次再呼叫時回傳舊快照且無副作用；不存在回 BatchNotFound，其餘不合法狀態回 NotRunnable。
- Busy、Conflict 或本地儲存不可用時，本次呼叫停止並交付原因，不繼續扣款。已開始的操作意圖及占用維持可供恢復查證；無法記錄外部結果時不得假設未扣款。
- 工作資料由既有系統保存 90 天，既有內部工作者已有執行權限；本例沒有其他安全、容量或效能門檻。

尚缺決策：
1. operationId 如何組成。
2. Debit 的 retentionDays 選擇。
3. 終局項目結果與檢查點是否同一交易提交。
4. lookup 為 NotFound 時如何處理。